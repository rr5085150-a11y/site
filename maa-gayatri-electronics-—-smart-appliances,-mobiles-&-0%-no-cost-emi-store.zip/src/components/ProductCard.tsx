import React, { useState } from 'react';
import { ShoppingBag, Star, Heart, Check, Plus, CreditCard, MessageCircle, Camera, Truck } from 'lucide-react';
import { ProductItem, ServiceOption } from '../types/tech';
import { ProductVisual } from './ProductVisual';

interface ProductCardProps {
  product: ProductItem;
  isCompared: boolean;
  onToggleCompare: (product: ProductItem) => void;
  onAddToCart: (product: ProductItem, paymentPlan?: 'full' | 'emi') => void;
  onBookService: (product: ProductItem, service: ServiceOption) => void;
  onViewDetails: (product: ProductItem) => void;
  onOpenEmiCalculator: (product: ProductItem) => void;
  onOpenExchangeModal: () => void;
  onOpenChangeImage?: (product: ProductItem) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isCompared,
  onToggleCompare,
  onAddToCart,
  onViewDetails,
  onOpenEmiCalculator,
  onOpenChangeImage
}) => {
  const [isWishlisted, setIsWishlisted] = useState(false);

  // Calculate discount percentage
  const discountPercent = Math.round(
    ((product.originalPrice - product.price) / product.originalPrice) * 100
  );

  const handleWhatsAppInquiry = (e: React.MouseEvent) => {
    e.stopPropagation();
    const msg = encodeURIComponent(
      `Hello Maa Gayatri Electronics, I would like to inquire about ${product.name} (Price: ₹${product.price.toLocaleString('en-IN')}, 0% EMI: ₹${product.emiPerMonth}/mo). Is it available in stock?`
    );
    window.open(`https://wa.me/919826054321?text=${msg}`, '_blank');
  };

  return (
    <div className="group bg-white rounded-3xl border border-[#E8EEEB] hover:border-[#C8DDD4] transition-all duration-300 shadow-2xs hover:shadow-lg flex flex-col overflow-hidden">
      {/* Product Image Stage */}
      <div
        className="relative h-60 w-full bg-[#F6F8F7] flex items-center justify-center p-4 cursor-pointer overflow-hidden"
        onClick={() => onViewDetails(product)}
      >
        {/* Discount Badge on top-left matching reference mockup (e.g. -15%, -20%) */}
        {discountPercent > 0 && (
          <div className="absolute top-3.5 left-3.5 z-10 bg-[#E8F5F1] text-[#00624A] text-xs font-extrabold px-2.5 py-1 rounded-lg border border-[#CDEADA] shadow-2xs">
            -{discountPercent}%
          </div>
        )}

        {/* Wishlist Heart on top-right matching reference mockup */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setIsWishlisted(!isWishlisted);
          }}
          aria-label="Save to Wishlist"
          className="absolute top-3.5 right-3.5 z-10 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-zinc-600 hover:text-rose-500 shadow-2xs border border-zinc-200/80 flex items-center justify-center transition-all hover:scale-105 active:scale-95"
        >
          <Heart
            className={`w-4 h-4 transition-colors ${
              isWishlisted ? 'fill-rose-500 text-rose-500' : ''
            }`}
          />
        </button>

        {/* Change Photo Trigger */}
        {onOpenChangeImage && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onOpenChangeImage(product);
            }}
            className="absolute bottom-3 left-3 px-2 py-1 rounded-lg text-[10px] font-bold bg-white/95 text-zinc-600 hover:text-zinc-950 hover:bg-white border border-zinc-200 shadow-2xs flex items-center gap-1 z-10 opacity-0 group-hover:opacity-100 transition-opacity"
            title="Update custom product photo"
          >
            <Camera className="w-3 h-3 text-zinc-500" />
            <span>Edit Photo</span>
          </button>
        )}

        {/* Compare specs button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onToggleCompare(product);
          }}
          className={`absolute bottom-3 right-3 px-2 py-1 rounded-lg text-[10px] font-medium transition-all flex items-center gap-1 z-10 shadow-2xs ${
            isCompared
              ? 'bg-[#00624A] text-white'
              : 'bg-white/90 text-zinc-700 hover:bg-white border border-zinc-200/90'
          }`}
          title="Compare specifications"
        >
          {isCompared ? (
            <>
              <Check className="w-3 h-3 text-white" />
              <span>Comparing</span>
            </>
          ) : (
            <>
              <Plus className="w-3 h-3 text-zinc-500" />
              <span>Compare</span>
            </>
          )}
        </button>

        {/* Centered Product Visual */}
        <div className="w-full h-full flex items-center justify-center transition-transform duration-500 group-hover:scale-105">
          <ProductVisual
            type={product.iconType}
            name={product.name}
            imageUrl={product.imageUrl}
            highlightText={product.energyRating}
          />
        </div>
      </div>

      {/* Card Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
        <div>
          {/* Brand & Category */}
          <div className="flex items-center justify-between text-xs text-zinc-400 mb-1">
            <span className="font-bold text-[#00624A] uppercase tracking-wider text-[10px]">
              {product.brand}
            </span>
            <span className="text-[11px] text-zinc-500 font-medium">
              {product.energyRating || 'OEM Certified'}
            </span>
          </div>

          {/* Product Title matching reference */}
          <h3
            onClick={() => onViewDetails(product)}
            className="text-sm sm:text-base font-bold text-zinc-950 group-hover:text-[#00624A] transition-colors cursor-pointer leading-snug line-clamp-1"
            title={product.name}
          >
            {product.name}
          </h3>

          {/* Star Rating with review count matching reference mockup (e.g. ★★★★★ (124)) */}
          <div className="flex items-center gap-1.5 mt-1.5">
            <div className="flex items-center text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className={`w-3.5 h-3.5 ${
                    i < Math.floor(product.rating)
                      ? 'fill-amber-400 text-amber-400'
                      : 'fill-zinc-200 text-zinc-200'
                  }`}
                />
              ))}
            </div>
            <span className="text-xs text-zinc-500 font-medium tabular-nums">
              ({product.reviewsCount})
            </span>
          </div>

          {/* Price & Struck-through original price matching reference */}
          <div className="flex items-baseline gap-2 mt-2.5">
            <span className="text-lg sm:text-xl font-extrabold text-zinc-950 tabular-nums">
              ₹{product.price.toLocaleString('en-IN')}
            </span>
            {product.originalPrice > product.price && (
              <span className="text-xs sm:text-sm text-zinc-400 line-through tabular-nums">
                ₹{product.originalPrice.toLocaleString('en-IN')}
              </span>
            )}
          </div>

          {/* 0% EMI Note */}
          <div className="mt-1 flex items-center justify-between text-[11px]">
            <span className="text-[#00624A] font-bold">
              or ₹{product.emiPerMonth.toLocaleString('en-IN')}/mo
            </span>
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onOpenEmiCalculator(product);
              }}
              className="text-zinc-500 hover:text-[#00624A] underline font-medium"
            >
              0% EMI Plans
            </button>
          </div>
        </div>

        {/* Primary Action Button: Emerald Full-Width Add to Cart matching mockup */}
        <div className="pt-2 space-y-2">
          <button
            type="button"
            onClick={() => onAddToCart(product, 'full')}
            className="w-full py-2.5 sm:py-3 px-4 rounded-xl bg-[#00624A] hover:bg-[#004D3A] text-white text-xs sm:text-sm font-bold shadow-md shadow-[#00624A]/20 transition-all flex items-center justify-center gap-2 hover:-translate-y-0.5 active:translate-y-0"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Add to Cart</span>
          </button>

          {/* Secondary WhatsApp & 0% EMI actions */}
          <div className="grid grid-cols-2 gap-2 text-[11px] font-semibold">
            <button
              type="button"
              onClick={handleWhatsAppInquiry}
              className="py-1.5 px-2 rounded-lg bg-[#E6F4EE] hover:bg-[#D7EFE4] text-[#00624A] flex items-center justify-center gap-1 transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </button>
            <button
              type="button"
              onClick={() => onAddToCart(product, 'emi')}
              className="py-1.5 px-2 rounded-lg bg-zinc-100 hover:bg-zinc-200 text-zinc-800 flex items-center justify-center gap-1 transition-colors"
            >
              <CreditCard className="w-3.5 h-3.5 text-[#00624A]" />
              <span>0% EMI Buy</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
