import React, { useState } from 'react';
import { X, Image as ImageIcon, Check, Sparkles, UploadCloud } from 'lucide-react';
import { ProductItem } from '../types/tech';

interface ImageManagerModalProps {
  product: ProductItem | null;
  isOpen: boolean;
  onClose: () => void;
  onSaveImageUrl: (productId: string, newUrl: string) => void;
}

export const ImageManagerModal: React.FC<ImageManagerModalProps> = ({
  product,
  isOpen,
  onClose,
  onSaveImageUrl
}) => {
  const [urlInput, setUrlInput] = useState(product?.imageUrl || '');

  if (!isOpen || !product) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (urlInput.trim()) {
      onSaveImageUrl(product.id, urlInput.trim());
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-zinc-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b border-zinc-200 flex items-center justify-between bg-zinc-50">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-zinc-950 text-white rounded-xl">
              <ImageIcon className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">
                Photo Customizer
              </span>
              <h3 className="text-sm font-bold text-zinc-950">
                Set Product Image for {product.name}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-zinc-900 rounded-full hover:bg-zinc-200 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-5 space-y-4">
          <div>
            <label className="text-xs font-bold text-zinc-700 block mb-1">
              Direct Image URL:
            </label>
            <input
              type="url"
              required
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="https://images.unsplash.com/photo-..."
              className="w-full text-xs p-3 bg-zinc-50 border border-zinc-300 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-zinc-950 font-mono"
            />
            <span className="text-[11px] text-zinc-400 block mt-1">
              Paste any direct image URL to instantly preview and update this product across the showroom.
            </span>
          </div>

          {/* Image Preview */}
          {urlInput && (
            <div className="space-y-1">
              <span className="text-[11px] font-semibold text-zinc-600">Live Photo Preview:</span>
              <div className="h-44 w-full rounded-2xl overflow-hidden border border-zinc-200 bg-zinc-100 flex items-center justify-center">
                <img
                  src={urlInput}
                  alt="Preview"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </div>
            </div>
          )}

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-zinc-100 hover:bg-zinc-200 text-zinc-700 text-xs font-semibold rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-zinc-950 hover:bg-zinc-800 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 shadow-xs"
            >
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>Apply Image</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
