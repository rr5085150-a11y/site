import React, { useState } from 'react';
import { Calculator, CheckCircle2, Shield, Clock, ArrowRight, Wrench } from 'lucide-react';
import { DIAGNOSTIC_CATEGORIES } from '../data/techCatalog';

interface DiagnosticEstimatorProps {
  onBookDirectService: (categoryLabel: string, issueName: string, estimatedPrice: string) => void;
}

export const DiagnosticEstimator: React.FC<DiagnosticEstimatorProps> = ({
  onBookDirectService
}) => {
  const [selectedCatId, setSelectedCatId] = useState<string>('ac');
  const currentCategory =
    DIAGNOSTIC_CATEGORIES.find((c) => c.id === selectedCatId) || DIAGNOSTIC_CATEGORIES[0];

  const [selectedModel, setSelectedModel] = useState<string>(currentCategory.models[0]);
  const [selectedIssueIdx, setSelectedIssueIdx] = useState<number>(0);

  const activeIssue = currentCategory.issues[selectedIssueIdx] || currentCategory.issues[0];

  const handleCategoryChange = (catId: string) => {
    setSelectedCatId(catId);
    const newCat = DIAGNOSTIC_CATEGORIES.find((c) => c.id === catId);
    if (newCat) {
      setSelectedModel(newCat.models[0]);
      setSelectedIssueIdx(0);
    }
  };

  return (
    <section id="diagnostic" className="py-16 md:py-24 bg-zinc-50 border-b border-zinc-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-12">
          {/* Unboxed metadata kicker */}
          <div className="text-xs font-bold uppercase tracking-wider text-zinc-500">
            Instant Cost Transparency
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-zinc-950 tracking-tight">
            Smart Appliance &amp; Battery Diagnostic Estimator
          </h2>
          <p className="text-sm sm:text-base text-zinc-600 leading-relaxed">
            Never overpay or get tricked with duplicate parts. Select your device and issue to view upfront factory pricing before our technician arrives at your door.
          </p>
        </div>

        {/* 3-Step Interactive Calculator Card */}
        <div className="max-w-4xl mx-auto bg-white rounded-3xl border border-zinc-200/90 shadow-md overflow-hidden">
          {/* Step 1: Category Bar */}
          <div className="p-4 sm:p-6 border-b border-zinc-200/80 bg-zinc-50/50">
            <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider block mb-3">
              Step 1: Choose Appliance / Device
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {DIAGNOSTIC_CATEGORIES.map((cat) => {
                const isSelected = cat.id === selectedCatId;
                return (
                  <button
                    key={cat.id}
                    onClick={() => handleCategoryChange(cat.id)}
                    className={`p-3 rounded-xl text-xs sm:text-sm font-semibold transition-all text-left flex items-center justify-between border ${
                      isSelected
                        ? 'bg-zinc-950 text-white border-zinc-950 shadow-xs'
                        : 'bg-white text-zinc-700 hover:bg-zinc-100 border-zinc-200/80'
                    }`}
                  >
                    <span>{cat.label}</span>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2 & Step 3 Split */}
          <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-8">
            {/* Step 2: Symptom & Model Selection */}
            <div className="md:col-span-7 space-y-6">
              <div>
                <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider block mb-2">
                  Step 2: Select Device Sub-Type
                </span>
                <select
                  value={selectedModel}
                  onChange={(e) => setSelectedModel(e.target.value)}
                  className="w-full text-sm bg-white border border-zinc-300 rounded-xl p-3 text-zinc-900 focus:outline-hidden focus:ring-2 focus:ring-zinc-950"
                >
                  {currentCategory.models.map((m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider block mb-2">
                  What issue are you facing?
                </span>
                <div className="space-y-2">
                  {currentCategory.issues.map((issue, idx) => {
                    const isPicked = idx === selectedIssueIdx;
                    return (
                      <div
                        key={idx}
                        onClick={() => setSelectedIssueIdx(idx)}
                        className={`p-3.5 rounded-xl border text-xs sm:text-sm font-medium cursor-pointer transition-all flex items-center justify-between ${
                          isPicked
                            ? 'bg-blue-50/70 border-blue-500 text-blue-950 shadow-xs'
                            : 'bg-white hover:bg-zinc-50 border-zinc-200 text-zinc-700'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 ${
                              isPicked
                                ? 'border-blue-600 bg-blue-600'
                                : 'border-zinc-300'
                            }`}
                          >
                            {isPicked && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                          </div>
                          <span>{issue.name}</span>
                        </div>
                        <span className="font-mono text-xs font-semibold text-zinc-600 tabular-nums">
                          {issue.estimate}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Step 3: Verified Instant Breakdown Card */}
            <div className="md:col-span-5 bg-zinc-950 text-white rounded-2xl p-6 flex flex-col justify-between space-y-6">
              <div>
                <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                  <div className="flex items-center gap-2">
                    <Calculator className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                      Upfront Fixed Quote
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-800">
                    GUARANTEED
                  </span>
                </div>

                <div className="mt-4 space-y-2">
                  <div className="text-xs text-zinc-400">Diagnosed Issue:</div>
                  <h4 className="text-sm font-bold text-white">{activeIssue.name}</h4>
                  <p className="text-xs text-zinc-400">
                    Recommended Fix: <span className="text-zinc-200">{activeIssue.likelyFix}</span>
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-zinc-800/80 space-y-2 text-xs">
                  <div className="flex justify-between text-zinc-400">
                    <span>Doorstep Visit &amp; Inspection:</span>
                    <span className="line-through text-zinc-500">₹299</span>
                    <span className="text-emerald-400 font-bold">FREE PROMO</span>
                  </div>
                  <div className="flex justify-between text-zinc-400">
                    <span>Genuine OEM Parts &amp; Consumables:</span>
                    <span className="text-white font-mono">Included</span>
                  </div>
                  <div className="flex justify-between text-zinc-400">
                    <span>Estimated Turnaround:</span>
                    <span className="text-white font-mono">{activeIssue.time}</span>
                  </div>
                  <div className="flex justify-between text-zinc-400">
                    <span>Written Warranty:</span>
                    <span className="text-emerald-400 font-semibold">365 Days</span>
                  </div>

                  <div className="pt-3 border-t border-zinc-800 flex items-baseline justify-between">
                    <span className="text-sm font-bold text-zinc-200">Total Price:</span>
                    <span className="text-2xl font-extrabold text-white font-mono tabular-nums">
                      {activeIssue.estimate}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={() =>
                  onBookDirectService(
                    `${currentCategory.label} (${selectedModel})`,
                    activeIssue.name,
                    activeIssue.estimate
                  )
                }
                className="w-full py-3 px-4 bg-white hover:bg-zinc-100 text-zinc-950 rounded-xl text-xs sm:text-sm font-bold transition-all shadow-md flex items-center justify-center gap-2"
              >
                <span>Book Instant Doorstep Repair</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
