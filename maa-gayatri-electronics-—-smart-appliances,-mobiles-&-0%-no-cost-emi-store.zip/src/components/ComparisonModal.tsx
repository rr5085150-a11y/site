import React, { useState } from 'react';
import { X, Check, ShoppingCart, ShieldCheck, Sparkles, AlertCircle } from 'lucide-react';
import { ProductItem } from '../types/tech';
import { ProductVisual } from './ProductVisual';

interface ComparisonModalProps {
  products: ProductItem[];
  isOpen: boolean;
  onClose: () => void;
  onRemoveProduct: (productId: string) => void;
  onAddToCart: (product: ProductItem) => void;
}

export const ComparisonModal: React.FC<ComparisonModalProps> = ({
  products,
  isOpen,
  onClose,
  onRemoveProduct,
  onAddToCart
}) => {
  const [highlightDiffs, setHighlightDiffs] = useState<boolean>(true);

  if (!isOpen) return null;

  // Gather unique spec keys across all compared products
  const allSpecKeys = Array.from(
    new Set(products.flatMap((p) => Object.keys(p.specs)))
  );

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl bg-white rounded-3xl shadow-2xl border border-zinc-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-zinc-200/80 flex items-center justify-between bg-zinc-50/80">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-500">
                Live Engineering Breakdown
              </span>
            </div>
            <h2 className="text-xl font-extrabold text-zinc-950">
              Hardware Specs &amp; Service Comparison
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {products.length > 1 && (
              <label className="hidden sm:flex items-center gap-2 text-xs font-medium text-zinc-700 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={highlightDiffs}
                  onChange={(e) => setHighlightDiffs(e.target.checked)}
                  className="rounded border-zinc-300 text-zinc-950 focus:ring-zinc-950"
                />
                <span>Highlight Differences</span>
              </label>
            )}

            <button
              onClick={onClose}
              className="p-2 text-zinc-400 hover:text-zinc-900 rounded-full hover:bg-zinc-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: Comparison Table */}
        <div className="overflow-x-auto flex-1 p-6">
          {products.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <AlertCircle className="w-10 h-10 text-zinc-400 mx-auto" />
              <p className="text-zinc-600 font-medium">No items currently selected for comparison.</p>
              <p className="text-xs text-zinc-400">
                Click "Compare" on any card in the catalog to inspect technical specs side-by-side.
              </p>
            </div>
          ) : (
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="p-4 text-left w-48 text-xs font-bold text-zinc-400 uppercase tracking-wider border-b border-zinc-200 align-top">
                    Device Model
                  </th>
                  {products.map((p) => (
                    <th
                      key={p.id}
                      className="p-4 text-left min-w-[240px] border-b border-zinc-200 align-top"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-[11px] font-semibold text-zinc-500 uppercase">
                          {p.brand}
                        </span>
                        <button
                          onClick={() => onRemoveProduct(p.id)}
                          className="text-zinc-400 hover:text-red-500 text-xs p-1 rounded"
                          title="Remove from comparison"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="h-28 w-full my-2 rounded-xl overflow-hidden border border-zinc-200/80">
                        <ProductVisual type={p.iconType} name={p.name} imageUrl={p.imageUrl} />
                      </div>

                      <h4 className="text-sm font-bold text-zinc-950 line-clamp-2 mt-1">
                        {p.name}
                      </h4>

                      <div className="mt-2 flex items-baseline gap-2">
                        <span className="text-lg font-extrabold text-zinc-950 tabular-nums">
                          ₹{p.price.toLocaleString('en-IN')}
                        </span>
                        <span className="text-xs text-zinc-400 line-through tabular-nums">
                          ₹{p.originalPrice.toLocaleString('en-IN')}
                        </span>
                      </div>

                      <button
                        onClick={() => {
                          onAddToCart(p);
                          onClose();
                        }}
                        className="mt-3 w-full py-2 px-3 bg-zinc-950 hover:bg-zinc-800 text-white rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1.5 shadow-xs"
                      >
                        <ShoppingCart className="w-3.5 h-3.5" />
                        <span>Select / Buy Unit</span>
                      </button>
                    </th>
                  ))}
                </tr>
              </thead>

              <tbody className="divide-y divide-zinc-200/70 text-xs text-zinc-800">
                {/* General Trust & Warranty Row */}
                <tr className="bg-zinc-50/50">
                  <td className="p-3 font-semibold text-zinc-600">Standard Warranty</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 font-medium">
                      <span className="flex items-center gap-1 text-emerald-700">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        {p.warrantyYears}-Year Manufacturer &amp; Store Warranty
                      </span>
                    </td>
                  ))}
                </tr>

                {/* Energy Rating / Capacity Tier */}
                <tr>
                  <td className="p-3 font-semibold text-zinc-600">Energy &amp; Efficiency Rating</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 font-mono">
                      {p.energyRating || 'Standard Commercial Grade'}
                    </td>
                  ))}
                </tr>

                {/* Doorstep Service Speed */}
                <tr className="bg-zinc-50/50">
                  <td className="p-3 font-semibold text-zinc-600">Service Response Window</td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 font-medium">
                      {p.deliveryDays === 0 ? (
                        <span className="text-blue-600 font-semibold">45-Minute Doorstep Technician</span>
                      ) : (
                        <span>{p.deliveryDays}-Day Express Delivery &amp; Install</span>
                      )}
                    </td>
                  ))}
                </tr>

                {/* Detailed Technical Specifications Grid */}
                {allSpecKeys.map((specKey) => {
                  const values = products.map((p) => p.specs[specKey] || '—');
                  const isDifferent =
                    products.length > 1 &&
                    values.some((v) => v !== values[0] && v !== '—');

                  return (
                    <tr
                      key={specKey}
                      className={
                        highlightDiffs && isDifferent
                          ? 'bg-amber-50/60 transition-colors'
                          : ''
                      }
                    >
                      <td className="p-3 font-semibold text-zinc-700">
                        <div className="flex items-center gap-1">
                          <span>{specKey}</span>
                          {highlightDiffs && isDifferent && (
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" title="Values differ" />
                          )}
                        </div>
                      </td>
                      {products.map((p) => (
                        <td key={p.id} className="p-3 font-mono text-zinc-900">
                          {p.specs[specKey] || (
                            <span className="text-zinc-400 font-sans italic">Not Applicable</span>
                          )}
                        </td>
                      ))}
                    </tr>
                  );
                })}

                {/* Certified Repair Options Summary */}
                <tr className="bg-zinc-50/50">
                  <td className="p-3 font-semibold text-zinc-600 align-top">
                    Popular Repair Services
                  </td>
                  {products.map((p) => (
                    <td key={p.id} className="p-3 space-y-1.5 align-top">
                      {p.services.slice(0, 2).map((srv) => (
                        <div key={srv.id} className="p-2 bg-white rounded-lg border border-zinc-200/80">
                          <div className="font-semibold text-zinc-900 flex justify-between">
                            <span>{srv.name}</span>
                            <span className="tabular-nums font-mono text-blue-600">
                              ₹{srv.price.toLocaleString('en-IN')}
                            </span>
                          </div>
                          <div className="text-[10px] text-zinc-500 mt-0.5">
                            ⏱ {srv.durationMinutes} mins · {srv.warrantyDays}-day warranty
                          </div>
                        </div>
                      ))}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-zinc-50 border-t border-zinc-200/80 flex items-center justify-between text-xs text-zinc-500">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>All specs certified against ISO 9001 and OEM engineering datasheets</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-zinc-200 hover:bg-zinc-300 text-zinc-800 rounded-lg font-medium transition-colors"
          >
            Close Comparison
          </button>
        </div>
      </div>
    </div>
  );
};
