import React from 'react';
import { X, ShieldCheck, Truck, Star, Wrench, ShoppingCart, CheckCircle2, MessageCircle } from 'lucide-react';
import { ProductItem, ServiceOption } from '../types/tech';
import { ProductVisual } from './ProductVisual';

interface ProductDetailModalProps {
  product: ProductItem | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: ProductItem) => void;
  onBookService: (product: ProductItem, service: ServiceOption) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen,
  onClose,
  onAddToCart,
  onBookService
}) => {
  if (!isOpen || !product) return null;

  const handleWhatsApp = () => {
    const msg = encodeURIComponent(
      `Hello Maa Gayatri Electronics, I am reviewing the ${product.name} (Price: ₹${product.price.toLocaleString('en-IN')}) and want to verify stock and EMI offers.`
    );
    window.open(`https://wa.me/919826054321?text=${msg}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-zinc-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-zinc-200/80 flex items-center justify-between bg-zinc-50">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-500">
              {product.brand} · {product.modelNumber}
            </span>
            <h2 className="text-xl font-extrabold text-zinc-950 mt-0.5">{product.name}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-zinc-900 rounded-full hover:bg-zinc-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto p-6 space-y-6">
          {/* Top visual & pricing banner */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
            <div className="h-56 rounded-2xl overflow-hidden border border-zinc-200/80">
              <ProductVisual
                type={product.iconType}
                name={product.name}
                imageUrl={product.imageUrl}
                highlightText={product.energyRating}
              />
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 text-xs">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span className="font-bold text-zinc-950 tabular-nums">{product.rating}</span>
                  <span className="text-zinc-400">({product.reviewsCount} customer reviews)</span>
                </div>
              </div>

              <div>
                <div className="text-2xl sm:text-3xl font-extrabold text-zinc-950 tabular-nums">
                  ₹{product.price.toLocaleString('en-IN')}
                </div>
                <div className="text-xs text-zinc-400 line-through tabular-nums mt-0.5">
                  Standard Retail MRP: ₹{product.originalPrice.toLocaleString('en-IN')}
                </div>
              </div>

              <div className="space-y-1.5 text-xs text-zinc-600">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>{product.warrantyYears}-Year Manufacturer Warranty &amp; Maa Gayatri Guarantee</span>
                </div>
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-blue-600" />
                  <span>
                    {product.deliveryDays === 0
                      ? 'Guaranteed 45-Min Doorstep Arrival'
                      : 'Free Express White-Glove Delivery'}
                  </span>
                </div>
              </div>

              <div className="space-y-2 pt-1">
                <button
                  onClick={() => {
                    onAddToCart(product);
                    onClose();
                  }}
                  className="w-full py-3 px-4 bg-[#00624A] hover:bg-[#004D3A] text-white rounded-xl text-sm font-bold transition-all shadow-md shadow-[#00624A]/20 flex items-center justify-center gap-2"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>Buy Electronics / Appliance Now</span>
                </button>

                <button
                  onClick={handleWhatsApp}
                  className="w-full py-2.5 px-4 bg-[#E6F4EE] hover:bg-[#D7EFE4] border border-[#CDEADA] text-[#00624A] rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-4 h-4 text-[#00624A]" />
                  <span>Chat with Showroom on WhatsApp</span>
                </button>
              </div>
            </div>
          </div>

          {/* Highlights */}
          <div className="bg-zinc-50 p-4 rounded-2xl border border-zinc-200/80 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-700">
              Key Engineering Innovations
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {product.highlights.map((h, i) => (
                <div key={i} className="text-xs text-zinc-700 flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>{h}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Full Specifications Table */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-700">
              Complete Technical Specifications
            </h4>
            <div className="border border-zinc-200 rounded-xl overflow-hidden divide-y divide-zinc-200 text-xs">
              {Object.entries(product.specs).map(([label, val]) => (
                <div key={label} className="grid grid-cols-12 p-3 bg-white hover:bg-zinc-50/50">
                  <span className="col-span-5 font-semibold text-zinc-600">{label}</span>
                  <span className="col-span-7 font-mono text-zinc-900">{val}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Available Repair & Service Menu */}
          <div className="space-y-3 pt-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-700 flex items-center gap-1.5">
              <Wrench className="w-3.5 h-3.5 text-zinc-700" />
              <span>Available Certified Repair &amp; Service Options</span>
            </h4>
            <div className="space-y-2">
              {product.services.map((srv) => (
                <div
                  key={srv.id}
                  className="p-3.5 bg-zinc-50 rounded-xl border border-zinc-200/90 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div>
                    <h5 className="text-xs font-bold text-zinc-950">{srv.name}</h5>
                    <p className="text-[11px] text-zinc-500 mt-0.5">{srv.description}</p>
                    <div className="flex gap-3 text-[10px] text-zinc-400 mt-1">
                      <span>⏱ {srv.durationMinutes} mins</span>
                      <span>🛡 {srv.warrantyDays}-Day Warranty</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-sm font-bold text-zinc-950 font-mono tabular-nums">
                      ₹{srv.price.toLocaleString('en-IN')}
                    </span>
                    <button
                      onClick={() => {
                        onBookService(product, srv);
                        onClose();
                      }}
                      className="py-1.5 px-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold transition-colors"
                    >
                      Book Visit
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
