import React, { useState } from 'react';
import { MessageCircle, X, Send, CheckCircle2, ShieldCheck, Sparkles } from 'lucide-react';
import { GAYATRI_LOGO_URL } from './Navbar';

export const WhatsAppFloat: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');

  const quickTemplates = [
    'Hi, I want to check 0% No-Cost EMI eligibility on Bajaj Finserv.',
    'Hi, I want to trade in my old appliance. What is the exchange value?',
    'Hi, is Daikin 1.5T AC available for same-day delivery and installation?',
    'Hi, I want to know about Sony Bravia 65" TV warranty & pricing.'
  ];

  const handleSend = (textToSend?: string) => {
    const finalMsg = textToSend || message || 'Hello Maa Gayatri Electronics, I would like to inquire about appliances.';
    const encoded = encodeURIComponent(finalMsg);
    window.open(`https://wa.me/919826054321?text=${encoded}`, '_blank');
    setIsOpen(false);
  };

  return (
    <>
      {/* Floating Action Trigger in Bottom Right */}
      <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end">
        {/* Tooltip prompt on desktop */}
        {!isOpen && (
          <div className="hidden sm:flex items-center gap-2 mb-2 bg-zinc-950 text-white text-[11px] font-semibold py-1 px-3 rounded-full shadow-lg border border-zinc-800 animate-bounce">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Chat with Showroom Expert</span>
          </div>
        )}

        <button
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Contact on WhatsApp"
          className="w-14 h-14 rounded-full bg-[#25D366] hover:bg-[#20ba59] text-white flex items-center justify-center shadow-[0_8px_25px_rgba(37,211,102,0.4)] transition-all hover:scale-105 active:scale-95 focus-visible:outline-hidden"
        >
          {isOpen ? (
            <X className="w-6 h-6" />
          ) : (
            <div className="relative">
              <MessageCircle className="w-7 h-7" />
              <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-white border-2 border-[#25D366] flex items-center justify-center">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-ping" />
              </span>
            </div>
          )}
        </button>
      </div>

      {/* WhatsApp Quick Chat Modal */}
      {isOpen && (
        <div className="fixed bottom-24 right-4 sm:right-6 z-50 w-[92vw] sm:w-[380px] bg-white rounded-3xl shadow-2xl border border-zinc-200 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200">
          {/* Header */}
          <div className="bg-[#075E54] p-4 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative w-10 h-10 rounded-full overflow-hidden border-2 border-white/80 shrink-0">
                <img
                  src={GAYATRI_LOGO_URL}
                  alt="Maa Gayatri"
                  className="w-full h-full object-cover bg-amber-50"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                  <span>Maa Gayatri Showroom</span>
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
                </h3>
                <span className="text-[11px] text-emerald-100 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-300" />
                  <span>Typically replies in 5 minutes</span>
                </span>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/10"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Chat Body */}
          <div className="p-4 bg-zinc-50 space-y-3 max-h-[360px] overflow-y-auto">
            <div className="p-3 bg-white rounded-2xl rounded-tl-xs shadow-2xs border border-zinc-200 text-xs text-zinc-800 space-y-1">
              <p className="font-semibold text-zinc-950">
                Namaste! Welcome to Maa Gayatri Electronics.
              </p>
              <p className="text-zinc-600">
                How can we assist you today with appliances, 0% No-Cost EMI, or old appliance trade-in?
              </p>
              <span className="text-[10px] text-zinc-400 block text-right">Showroom Assistant</span>
            </div>

            {/* Quick Suggestions */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 block">
                Quick Questions:
              </span>
              {quickTemplates.map((tmpl, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSend(tmpl)}
                  className="w-full text-left p-2.5 bg-white hover:bg-emerald-50 hover:border-emerald-300 border border-zinc-200/90 rounded-xl text-xs text-zinc-700 transition-colors flex items-center justify-between"
                >
                  <span className="line-clamp-1">{tmpl}</span>
                  <Send className="w-3 h-3 text-emerald-600 shrink-0 ml-1" />
                </button>
              ))}
            </div>
          </div>

          {/* Input Footer */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-3 bg-white border-t border-zinc-200 flex items-center gap-2"
          >
            <input
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message here..."
              className="flex-1 text-xs p-2.5 bg-zinc-50 border border-zinc-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-emerald-600"
            />
            <button
              type="submit"
              className="p-2.5 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-xl shadow-xs transition-all flex items-center justify-center shrink-0"
              title="Send to WhatsApp"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
