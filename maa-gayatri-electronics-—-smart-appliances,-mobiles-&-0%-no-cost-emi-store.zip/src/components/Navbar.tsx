import React, { useState } from 'react';
import { ShoppingBag, Search, Scale, CreditCard, RefreshCw, Menu, X, MessageCircle, User } from 'lucide-react';
import { CartBookingItem } from '../types/tech';

interface NavbarProps {
  cartItems: CartBookingItem[];
  comparedCount: number;
  onOpenCart: () => void;
  onOpenCompare: () => void;
  onOpenEmiModal: () => void;
  onOpenExchangeModal: () => void;
  onScrollToSection: (id: string) => void;
  searchQuery?: string;
  onSearchChange?: (val: string) => void;
}

export const GAYATRI_LOGO_URL =
  'https://pujaabhishekam-crm.s3.ap-south-1.amazonaws.com/assets/01J826CB2NQAD7J3YXPGDZ2FWX.jpg';

export const Navbar: React.FC<NavbarProps> = ({
  cartItems,
  comparedCount,
  onOpenCart,
  onOpenCompare,
  onOpenEmiModal,
  onOpenExchangeModal,
  onScrollToSection,
  searchQuery = '',
  onSearchChange
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [logoError, setLogoError] = useState(false);
  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const handleNavClick = (sectionId: string) => {
    onScrollToSection(sectionId);
    setIsMobileMenuOpen(false);
  };

  const handleWhatsAppChat = () => {
    const msg = encodeURIComponent(
      'Hello Maa Gayatri Electronics! I am visiting your website and would like assistance with products and 0% No-Cost EMI.'
    );
    window.open(`https://wa.me/919826054321?text=${msg}`, '_blank');
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-zinc-200/90 transition-all shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 sm:h-20 flex items-center justify-between gap-4 lg:gap-8">
        {/* Zone 1: Brand Wordmark matching reference mockup */}
        <button
          onClick={() => handleNavClick('hero')}
          className="text-left flex items-center gap-3 whitespace-nowrap shrink-0 group focus-visible:outline-hidden"
        >
          {/* Shopping Bag Badge with Maa Gayatri Emblem */}
          <div className="relative w-10 h-10 sm:w-11 sm:h-11 rounded-2xl bg-[#E6F4EE] border border-[#C6E6D8] flex items-center justify-center p-1 shadow-2xs shrink-0 group-hover:scale-105 transition-transform overflow-hidden">
            {!logoError ? (
              <img
                src={GAYATRI_LOGO_URL}
                alt="Maa Gayatri"
                referrerPolicy="no-referrer"
                onError={() => setLogoError(true)}
                className="w-full h-full object-cover rounded-xl"
              />
            ) : (
              <ShoppingBag className="w-6 h-6 text-[#00624A]" />
            )}
          </div>

          <div className="flex flex-col">
            <span className="text-lg sm:text-xl font-extrabold tracking-tight text-zinc-950 group-hover:text-[#00624A] transition-colors leading-tight">
              Maa Gayatri
            </span>
            <span className="text-[10px] uppercase font-bold tracking-wider text-[#00624A] leading-none">
              Electronics &amp; Appliances
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links matching reference */}
        <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-xs sm:text-sm font-semibold text-zinc-600">
          <button
            onClick={() => handleNavClick('hero')}
            className="hover:text-[#00624A] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('catalog')}
            className="hover:text-[#00624A] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Shop
          </button>
          <button
            onClick={() => handleNavClick('categories')}
            className="hover:text-[#00624A] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Categories
          </button>
          <button
            onClick={onOpenEmiModal}
            className="hover:text-[#00624A] text-[#00624A] transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 font-bold py-1"
          >
            <CreditCard className="w-3.5 h-3.5" />
            <span>0% EMI</span>
          </button>
          <button
            onClick={onOpenExchangeModal}
            className="hover:text-[#00624A] transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 py-1"
          >
            <RefreshCw className="w-3.5 h-3.5 text-zinc-400" />
            <span>Trade-In</span>
          </button>
          <button
            onClick={() => handleNavClick('trust-proof')}
            className="hover:text-[#00624A] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            About
          </button>
          <button
            onClick={handleWhatsAppChat}
            className="hover:text-[#00624A] transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Contact
          </button>
        </nav>

        {/* Zone 3: Search Pill, WhatsApp, Account & Cart Drawer */}
        <div className="flex items-center gap-2.5 sm:gap-4 shrink-0">
          {/* Pill Search Input matching the reference */}
          {onSearchChange && (
            <div className="relative hidden md:block w-48 lg:w-64">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search products..."
                className="w-full pl-9 pr-3 py-2 bg-[#F6F8F7] hover:bg-[#EEF4F1] focus:bg-white border border-[#E2E8E4] focus:border-[#00624A] rounded-full text-xs text-zinc-900 focus:outline-hidden transition-all placeholder:text-zinc-400 shadow-2xs"
              />
            </div>
          )}

          {/* Quick WhatsApp Concierge Button */}
          <button
            onClick={handleWhatsAppChat}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-[#00624A] bg-[#E6F4EE] hover:bg-[#D7EFE4] rounded-full transition-colors whitespace-nowrap shrink-0"
            title="Chat directly on WhatsApp"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>WhatsApp</span>
          </button>

          {/* Compare Pill if items compared */}
          {comparedCount > 0 && (
            <button
              onClick={onOpenCompare}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-zinc-800 bg-[#F6F8F7] hover:bg-zinc-200 rounded-full transition-colors whitespace-nowrap shrink-0 border border-zinc-200"
              title="Compare specifications"
            >
              <Scale className="w-3.5 h-3.5 text-zinc-950" />
              <span className="hidden sm:inline">Compare</span>
              <span className="font-bold tabular-nums">({comparedCount})</span>
            </button>
          )}

          {/* Account Icon matching reference */}
          <button
            onClick={() => handleNavClick('trust-proof')}
            className="p-2 sm:p-2.5 rounded-full hover:bg-zinc-100 text-zinc-700 transition-colors"
            title="Customer Support & Account"
            aria-label="User Account"
          >
            <User className="w-5 h-5" />
          </button>

          {/* Cart Bag with Emerald Badge Count matching reference mockup */}
          <button
            onClick={onOpenCart}
            className="relative p-2 sm:p-2.5 rounded-full hover:bg-zinc-100 text-zinc-800 transition-colors"
            title="View Cart & Orders"
            aria-label="Shopping Cart"
          >
            <ShoppingBag className="w-5 h-5 text-zinc-900" />
            {totalCartCount > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-[#00624A] text-white text-[10px] font-bold rounded-full flex items-center justify-center tabular-nums shadow-xs animate-in zoom-in-75">
                {totalCartCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Hamburger */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl text-zinc-700 hover:text-zinc-950 hover:bg-zinc-100 transition-colors"
            aria-label="Toggle Navigation"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-zinc-200/90 bg-white/98 backdrop-blur-md px-4 py-4 space-y-3 animate-in slide-in-from-top-2">
          {onSearchChange && (
            <div className="relative w-full mb-3">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search electronics, appliances..."
                className="w-full pl-9 pr-3 py-2 bg-[#F6F8F7] border border-[#E2E8E4] rounded-full text-xs text-zinc-900 focus:outline-hidden"
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
            <button
              onClick={() => handleNavClick('hero')}
              className="p-2.5 text-left bg-zinc-50 rounded-xl hover:bg-zinc-100 text-zinc-900"
            >
              Home
            </button>
            <button
              onClick={() => handleNavClick('catalog')}
              className="p-2.5 text-left bg-zinc-50 rounded-xl hover:bg-zinc-100 text-zinc-900"
            >
              Shop Catalog
            </button>
            <button
              onClick={() => handleNavClick('categories')}
              className="p-2.5 text-left bg-zinc-50 rounded-xl hover:bg-zinc-100 text-zinc-900"
            >
              Browse Categories
            </button>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenEmiModal();
              }}
              className="p-2.5 text-left bg-[#E6F4EE] text-[#00624A] font-bold rounded-xl"
            >
              0% No-Cost EMI
            </button>
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenExchangeModal();
              }}
              className="p-2.5 text-left bg-zinc-50 rounded-xl hover:bg-zinc-100 text-zinc-900"
            >
              Trade-In Offers
            </button>
            <button
              onClick={handleWhatsAppChat}
              className="p-2.5 text-left bg-emerald-500 text-white font-bold rounded-xl flex items-center gap-1.5"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>WhatsApp Chat</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
