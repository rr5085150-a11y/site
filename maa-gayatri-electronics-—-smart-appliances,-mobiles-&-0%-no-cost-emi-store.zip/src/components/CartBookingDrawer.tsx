import React, { useState } from 'react';
import { X, Trash2, ShieldCheck, Clock, CheckCircle2, ArrowRight, Truck, CreditCard, RefreshCw, MessageCircle } from 'lucide-react';
import { CartBookingItem, CustomerBookingForm } from '../types/tech';

interface CartBookingDrawerProps {
  isOpen: boolean;
  cartItems: CartBookingItem[];
  exchangeDiscount: number;
  exchangeDeviceName?: string;
  onClose: () => void;
  onUpdateQuantity: (id: string, delta: number) => void;
  onTogglePaymentPlan: (id: string, plan: 'full' | 'emi') => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  onOpenExchangeModal: () => void;
}

export const CartBookingDrawer: React.FC<CartBookingDrawerProps> = ({
  isOpen,
  cartItems,
  exchangeDiscount,
  exchangeDeviceName,
  onClose,
  onUpdateQuantity,
  onTogglePaymentPlan,
  onRemoveItem,
  onClearCart,
  onOpenExchangeModal
}) => {
  const [isConfirmed, setIsConfirmed] = useState(false);
  const [confirmationId, setConfirmationId] = useState('');

  const [form, setForm] = useState<CustomerBookingForm>({
    fullName: '',
    phoneNumber: '',
    streetAddress: '',
    city: 'Mumbai',
    postalCode: '',
    preferredDate: 'Today (Express Same-Day)',
    preferredSlot: 'Express Delivery + Installation',
    paymentMethod: 'emi_bajaj',
    serviceNotes: ''
  });

  if (!isOpen) return null;

  const rawSubtotal = cartItems.reduce((acc, item) => {
    const itemPrice =
      item.type === 'repair' && item.selectedService
        ? item.selectedService.price
        : item.product.price;
    return acc + itemPrice * item.quantity;
  }, 0);

  const appliedExchangeDeduction = Math.min(rawSubtotal, exchangeDiscount);
  const finalPayable = Math.max(0, rawSubtotal - appliedExchangeDeduction);

  const emiItems = cartItems.filter((i) => i.paymentPlan === 'emi');
  const estimatedMonthlyEmi = emiItems.length > 0
    ? Math.round(
        emiItems.reduce((acc, item) => acc + item.product.emiPerMonth * item.quantity, 0)
      )
    : Math.round(finalPayable / 6);

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.fullName || !form.phoneNumber || !form.streetAddress) {
      return;
    }
    const orderNum = 'MG-' + Math.floor(100000 + Math.random() * 900000);
    setConfirmationId(orderNum);
    setIsConfirmed(true);
  };

  const handleReset = () => {
    setIsConfirmed(false);
    onClearCart();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-zinc-950/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-6 sm:pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between border-l border-zinc-200">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-zinc-200 flex items-center justify-between bg-zinc-50">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                Maa Gayatri Electronics
              </span>
              <h2 className="text-base sm:text-lg font-bold text-zinc-950">
                {isConfirmed ? 'Order & Finance Confirmed' : 'Shopping Bag & 0% EMI'}
              </h2>
              <span className="text-xs text-zinc-500">
                {cartItems.length} {cartItems.length === 1 ? 'item' : 'items'} in order
              </span>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-zinc-400 hover:text-zinc-900 rounded-full hover:bg-zinc-200 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Body */}
          <div className="overflow-y-auto flex-1 p-4 sm:p-6 space-y-6">
            {isConfirmed ? (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-10 h-10" />
                </div>

                <div className="space-y-1">
                  <h3 className="text-xl font-extrabold text-zinc-950">
                    Order Successfully Placed!
                  </h3>
                  <p className="text-xs text-zinc-500">
                    Booking Reference ID: <span className="font-mono font-bold text-zinc-900">{confirmationId}</span>
                  </p>
                </div>

                <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-200 text-left text-xs space-y-2">
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Customer Name:</span>
                    <span className="font-semibold text-zinc-900">{form.fullName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Contact Number:</span>
                    <span className="font-semibold text-zinc-900 font-mono">{form.phoneNumber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Delivery Address:</span>
                    <span className="font-semibold text-zinc-900 text-right">{form.streetAddress}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-500">Selected Finance Plan:</span>
                    <span className="font-semibold text-emerald-700">
                      {form.paymentMethod === 'emi_bajaj'
                        ? '0% No-Cost EMI (Bajaj Finserv)'
                        : form.paymentMethod === 'emi_credit_card'
                        ? 'Bank Credit/Debit Card EMI'
                        : 'Cash on Delivery / UPI'}
                    </span>
                  </div>
                  {appliedExchangeDeduction > 0 && (
                    <div className="flex justify-between text-emerald-700 font-semibold">
                      <span>Trade-In Discount:</span>
                      <span>-₹{appliedExchangeDeduction.toLocaleString('en-IN')}</span>
                    </div>
                  )}
                  <div className="pt-2 border-t border-zinc-200 flex justify-between font-bold text-sm">
                    <span>Net Payable Amount:</span>
                    <span className="font-mono tabular-nums">₹{finalPayable.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-[11px] text-emerald-800 flex items-center gap-2 text-left">
                  <Clock className="w-4 h-4 shrink-0 text-emerald-600" />
                  <span>
                    Our showroom dispatch manager has been notified. You will receive an SMS and telephone call to coordinate same-day delivery and installation.
                  </span>
                </div>

                <div className="space-y-2 pt-2">
                  <button
                    onClick={() => {
                      const msg = encodeURIComponent(
                        `Hello Maa Gayatri Electronics, I just placed order #${confirmationId} for ₹${finalPayable.toLocaleString('en-IN')}. Name: ${form.fullName}, Phone: ${form.phoneNumber}, Address: ${form.streetAddress}. Please confirm delivery timing.`
                      );
                      window.open(`https://wa.me/919826054321?text=${msg}`, '_blank');
                    }}
                    className="w-full py-3 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Send Order Details via WhatsApp</span>
                  </button>

                  <button
                    onClick={handleReset}
                    className="w-full py-3 bg-zinc-950 hover:bg-zinc-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs"
                  >
                    Continue Shopping
                  </button>
                </div>
              </div>
            ) : cartItems.length === 0 ? (
              <div className="text-center py-12 space-y-3">
                <Truck className="w-10 h-10 text-zinc-300 mx-auto" />
                <p className="text-sm font-semibold text-zinc-700">Your shopping bag is empty.</p>
                <p className="text-xs text-zinc-500 max-w-xs mx-auto">
                  Explore our selection of Inverter ACs, 4K Smart TVs, Bespoke Refrigerators, and Washing Machines to order on 0% No-Cost EMI.
                </p>
              </div>
            ) : (
              <>
                {/* List of Cart Items */}
                <div className="space-y-3">
                  {cartItems.map((item) => {
                    const price =
                      item.type === 'repair' && item.selectedService
                        ? item.selectedService.price
                        : item.product.price;

                    return (
                      <div
                        key={item.id}
                        className="p-3.5 bg-zinc-50 rounded-2xl border border-zinc-200/90 flex flex-col gap-2.5 text-xs"
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="space-y-1 flex-1">
                            <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">
                              {item.product.brand} · {item.product.category.toUpperCase()}
                            </span>
                            <h4 className="font-bold text-zinc-950 leading-snug">{item.product.name}</h4>
                            <div className="text-sm font-extrabold text-zinc-950 font-mono tabular-nums">
                              ₹{price.toLocaleString('en-IN')}
                            </div>
                          </div>

                          <div className="flex flex-col items-end justify-between">
                            <button
                              onClick={() => onRemoveItem(item.id)}
                              className="text-zinc-400 hover:text-red-500 p-1 rounded"
                              title="Remove item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>

                            <div className="flex items-center border border-zinc-300 rounded-lg overflow-hidden bg-white mt-2">
                              <button
                                onClick={() => onUpdateQuantity(item.id, -1)}
                                className="px-2 py-0.5 text-zinc-600 hover:bg-zinc-100"
                              >
                                -
                              </button>
                              <span className="px-2 py-0.5 font-semibold font-mono tabular-nums">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => onUpdateQuantity(item.id, 1)}
                                className="px-2 py-0.5 text-zinc-600 hover:bg-zinc-100"
                              >
                                +
                              </button>
                            </div>
                          </div>
                        </div>

                        {/* Payment Mode Selector */}
                        {item.type === 'purchase' && (
                          <div className="pt-2 border-t border-zinc-200/60 flex items-center justify-between">
                            <span className="text-[11px] text-zinc-500 font-medium">Payment Option:</span>
                            <div className="flex gap-1.5">
                              <button
                                type="button"
                                onClick={() => onTogglePaymentPlan(item.id, 'emi')}
                                className={`px-2 py-1 rounded-md text-[10px] font-bold transition-all ${
                                  item.paymentPlan === 'emi'
                                    ? 'bg-emerald-700 text-white shadow-xs'
                                    : 'bg-zinc-200 text-zinc-700'
                                }`}
                              >
                                0% EMI (₹{item.product.emiPerMonth}/mo)
                              </button>
                              <button
                                type="button"
                                onClick={() => onTogglePaymentPlan(item.id, 'full')}
                                className={`px-2 py-1 rounded-md text-[10px] font-bold transition-all ${
                                  item.paymentPlan === 'full'
                                    ? 'bg-zinc-950 text-white'
                                    : 'bg-zinc-200 text-zinc-700'
                                }`}
                              >
                                Full Cash / UPI
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                {/* Trade-In Discount Apply Card */}
                {appliedExchangeDeduction > 0 ? (
                  <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-bold text-emerald-950 block">Trade-In Applied:</span>
                      <span className="text-[11px] text-emerald-700">{exchangeDeviceName}</span>
                    </div>
                    <span className="text-sm font-extrabold text-emerald-900 font-mono">
                      -₹{appliedExchangeDeduction.toLocaleString('en-IN')}
                    </span>
                  </div>
                ) : (
                  <div
                    onClick={onOpenExchangeModal}
                    className="p-3 bg-zinc-50 hover:bg-zinc-100 rounded-xl border border-dashed border-zinc-300 flex items-center justify-between text-xs cursor-pointer"
                  >
                    <div className="flex items-center gap-2 text-zinc-700 font-semibold">
                      <RefreshCw className="w-4 h-4 text-emerald-600" />
                      <span>Trading in an old appliance?</span>
                    </div>
                    <span className="text-emerald-700 font-bold text-[11px]">Save Up to ₹10,000</span>
                  </div>
                )}

                {/* Customer Details Form */}
                <form id="booking-form" onSubmit={handleCheckout} className="space-y-4 pt-2 border-t border-zinc-200">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-zinc-700">
                    Delivery &amp; Customer Information
                  </h4>

                  <div className="space-y-2.5 text-xs">
                    <div>
                      <label className="block text-zinc-600 font-medium mb-1">Full Name *</label>
                      <input
                        type="text"
                        required
                        value={form.fullName}
                        onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                        placeholder="e.g. Rajesh Kumar"
                        className="w-full p-2.5 bg-white border border-zinc-300 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-zinc-950"
                      />
                    </div>

                    <div>
                      <label className="block text-zinc-600 font-medium mb-1">Mobile Number (For Delivery &amp; OTP) *</label>
                      <input
                        type="tel"
                        required
                        value={form.phoneNumber}
                        onChange={(e) => setForm({ ...form, phoneNumber: e.target.value })}
                        placeholder="+91 98765 43210"
                        className="w-full p-2.5 bg-white border border-zinc-300 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-zinc-950"
                      />
                    </div>

                    <div>
                      <label className="block text-zinc-600 font-medium mb-1">Street Address / Landmark *</label>
                      <textarea
                        required
                        rows={2}
                        value={form.streetAddress}
                        onChange={(e) => setForm({ ...form, streetAddress: e.target.value })}
                        placeholder="Flat / House Number, Apartment, Street Name..."
                        className="w-full p-2.5 bg-white border border-zinc-300 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-zinc-950"
                      />
                    </div>

                    <div>
                      <label className="block text-zinc-600 font-medium mb-1">Payment Method &amp; Finance *</label>
                      <select
                        value={form.paymentMethod}
                        onChange={(e) => setForm({ ...form, paymentMethod: e.target.value as any })}
                        className="w-full p-2.5 bg-white border border-zinc-300 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-zinc-950 font-medium"
                      >
                        <option value="emi_bajaj">0% No-Cost EMI (Bajaj Finserv Card - Zero Down)</option>
                        <option value="emi_credit_card">Bank Credit/Debit Card EMI (HDFC, ICICI, SBI)</option>
                        <option value="cod">Cash on Delivery (Pay after installation)</option>
                        <option value="upi">UPI / Net Banking at Doorstep</option>
                        <option value="store_pickup">Direct Showroom Pickup (Maa Gayatri Store)</option>
                      </select>
                    </div>
                  </div>
                </form>

                {/* Price Summary Breakdown */}
                <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-200/80 space-y-2 text-xs">
                  <div className="flex justify-between text-zinc-600">
                    <span>Appliance Total:</span>
                    <span className="font-mono tabular-nums">₹{rawSubtotal.toLocaleString('en-IN')}</span>
                  </div>

                  {appliedExchangeDeduction > 0 && (
                    <div className="flex justify-between text-emerald-700 font-bold">
                      <span>Trade-In Discount:</span>
                      <span>-₹{appliedExchangeDeduction.toLocaleString('en-IN')}</span>
                    </div>
                  )}

                  <div className="flex justify-between text-zinc-600">
                    <span>Delivery &amp; Installation:</span>
                    <span className="text-emerald-600 font-bold">Complimentary (FREE)</span>
                  </div>

                  <div className="pt-2 border-t border-zinc-200 flex justify-between font-bold text-sm text-zinc-950">
                    <span>Net Amount Payable:</span>
                    <span className="text-base font-extrabold font-mono tabular-nums">
                      ₹{finalPayable.toLocaleString('en-IN')}
                    </span>
                  </div>

                  {form.paymentMethod.startsWith('emi') && (
                    <div className="p-2.5 bg-emerald-100/70 rounded-lg text-emerald-950 text-[11px] font-bold flex justify-between">
                      <span>Monthly Installment (~6 Months):</span>
                      <span className="font-mono text-xs">₹{estimatedMonthlyEmi.toLocaleString('en-IN')}/mo</span>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Drawer Footer */}
          {!isConfirmed && cartItems.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-zinc-200 bg-white">
              <button
                type="submit"
                form="booking-form"
                className="w-full py-3.5 bg-[#00624A] hover:bg-[#004D3A] text-white rounded-xl text-sm font-bold transition-all shadow-md shadow-[#00624A]/20 flex items-center justify-center gap-2 hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>Confirm Order &amp; Delivery</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
