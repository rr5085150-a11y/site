import React, { useState, useEffect } from 'react';
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Truck,
  ShieldCheck,
  Headphones,
  CreditCard,
  RefreshCw,
  Sparkles,
  Zap,
  CheckCircle2
} from 'lucide-react';
import { TechCategory } from '../types/tech';

interface HeroProps {
  selectedCategory: TechCategory;
  onSelectCategory: (cat: TechCategory) => void;
  onOpenCompare: () => void;
  onOpenEmiModal: () => void;
  onOpenExchangeModal: () => void;
  onScrollToCatalog: () => void;
}

interface ShowcaseSlide {
  id: string;
  badge: string;
  title: string;
  subtitle: string;
  highlightCategory: TechCategory;
  devices: {
    name: string;
    specs: string;
    image: string;
    price: string;
    tag?: string;
    position: string;
  }[];
}

const SHOWCASE_SLIDES: ShowcaseSlide[] = [
  {
    id: 'flagship-apple-ecosystem',
    badge: 'Flagship Collection 2026',
    title: 'Flagship Mobile & Computing Ecosystem',
    subtitle: 'M2 Silicon · Titanium Aerospace Design · Spatial Audio',
    highlightCategory: 'mobiles',
    devices: [
      {
        name: 'iPhone 15 Pro',
        specs: 'Titanium · A17 Pro Bionic',
        image: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=700&q=80',
        price: '₹1,19,990',
        tag: '-15%',
        position: 'w-28 sm:w-36 lg:w-40 z-20 -translate-x-10 sm:-translate-x-16 translate-y-3'
      },
      {
        name: 'MacBook Air M2',
        specs: 'Liquid Retina · 18h Battery',
        image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=900&q=80',
        price: '₹94,990',
        tag: 'Best Seller',
        position: 'w-56 sm:w-72 lg:w-80 z-10 translate-x-12 sm:translate-x-20 -translate-y-4'
      },
      {
        name: 'AirPods Pro (2nd Gen)',
        specs: '2x Active Noise Cancellation',
        image: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?auto=format&fit=crop&w=500&q=80',
        price: '₹22,990',
        tag: '-20%',
        position: 'w-24 sm:w-28 lg:w-32 z-30 translate-x-4 sm:translate-x-8 translate-y-12 sm:translate-y-16'
      },
      {
        name: 'Galaxy Watch 6 LTE',
        specs: 'Sapphire Crystal · ECG',
        image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=500&q=80',
        price: '₹26,990',
        tag: 'LTE Calling',
        position: 'w-20 sm:w-26 lg:w-28 z-20 -translate-x-24 sm:-translate-x-32 translate-y-10 sm:translate-y-12'
      }
    ]
  },
  {
    id: 'smart-cinema-oled',
    badge: '4K Home Theatre & Sound',
    title: 'Sony Bravia 4K OLED Cinema & Dolby Atmos',
    subtitle: 'Cognitive XR Processor · 120Hz Gaming · Wireless Subwoofer',
    highlightCategory: 'tv',
    devices: [
      {
        name: 'Sony Bravia 65" 4K XR OLED',
        specs: 'Cognitive XR · 120Hz VRR',
        image: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&w=900&q=80',
        price: '₹1,14,990',
        tag: 'IMAX Enhanced',
        position: 'w-64 sm:w-80 lg:w-96 z-10 -translate-y-4'
      },
      {
        name: 'Dolby Atmos Soundbar 400W',
        specs: 'Wireless Subwoofer & DTS:X',
        image: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=500&q=80',
        price: '₹24,990',
        tag: 'Spatial Audio',
        position: 'w-44 sm:w-56 z-30 translate-y-16'
      }
    ]
  },
  {
    id: 'eco-smart-appliances',
    badge: '5-Star Energy Saver',
    title: 'Daikin Triple Display AC & Samsung Bespoke',
    subtitle: 'Dew Clean Inverter · Twin Cooling Plus · Zero Down Payment',
    highlightCategory: 'ac',
    devices: [
      {
        name: 'Daikin 1.5T 5-Star AC',
        specs: 'Copper Condenser · Dew Clean',
        image: 'https://images.unsplash.com/photo-1614633833026-06204c6a6f69?auto=format&fit=crop&w=700&q=80',
        price: '₹44,990',
        tag: 'ISEER 5.2',
        position: 'w-48 sm:w-60 lg:w-68 z-20 -translate-x-12 sm:-translate-x-18 translate-y-4'
      },
      {
        name: 'Samsung Bespoke 580L Fridge',
        specs: 'French Door · FlexZone',
        image: 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?auto=format&fit=crop&w=700&q=80',
        price: '₹86,990',
        tag: '20-Yr Warranty',
        position: 'w-40 sm:w-52 lg:w-56 z-10 translate-x-16 sm:translate-x-24 -translate-y-3'
      }
    ]
  },
  {
    id: 'backup-power-systems',
    badge: 'Uninterrupted Home Backup',
    title: 'Luminous Pure Sinewave Inverter + 150Ah Battery',
    subtitle: 'Zero Fan Humming · 6-Hour Emergency Backup · Doorstep Trolley Setup',
    highlightCategory: 'inverter',
    devices: [
      {
        name: 'Luminous EcoVolt 1100 Pure Sinewave',
        specs: '900VA / 756W · ABCC Smart Charging',
        image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=700&q=80',
        price: '₹18,990',
        tag: 'Complete Set',
        position: 'w-52 sm:w-64 lg:w-72 z-20 -translate-y-2'
      }
    ]
  }
];

export const Hero: React.FC<HeroProps> = ({
  onOpenEmiModal,
  onOpenExchangeModal,
  onScrollToCatalog,
  onSelectCategory
}) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [isAutoPaused, setIsAutoPaused] = useState(false);

  const activeSlide = SHOWCASE_SLIDES[currentSlideIndex];

  // Subtle auto-advance every 6 seconds unless user pauses/hovers
  useEffect(() => {
    if (isAutoPaused) return;
    const interval = setInterval(() => {
      setCurrentSlideIndex((prev) => (prev === SHOWCASE_SLIDES.length - 1 ? 0 : prev + 1));
    }, 6000);
    return () => clearInterval(interval);
  }, [isAutoPaused]);

  const handlePrevSlide = () => {
    setCurrentSlideIndex((prev) => (prev === 0 ? SHOWCASE_SLIDES.length - 1 : prev - 1));
  };

  const handleNextSlide = () => {
    setCurrentSlideIndex((prev) => (prev === SHOWCASE_SLIDES.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="hero" className="relative pt-6 sm:pt-12 pb-14 sm:pb-20 bg-white overflow-hidden border-b border-zinc-200/80">
      {/* Background Soft Curved Ambient Arc matching reference design */}
      <div className="absolute top-0 right-0 w-[65%] h-[560px] bg-gradient-to-bl from-[#EBF5F1] via-[#F4FAF7] to-transparent rounded-bl-[180px] -z-10 pointer-events-none" />
      <div className="absolute top-1/3 right-1/4 w-96 h-96 rounded-full bg-[#00624A]/5 blur-3xl -z-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Premium Typography & Conversion Actions */}
          <div className="lg:col-span-6 space-y-6">
            {/* Pill tag matching reference "✦ Nouveauté" */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#E6F4EE] border border-[#CDEADA] text-xs font-bold text-[#00624A] shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-[#00624A]" />
              <span>New Arrival · Certified Tech &amp; Home Appliances</span>
            </div>

            {/* Display Headline matching "La technologie à portée de main" */}
            <h1 className="text-3xl sm:text-5xl lg:text-[56px] font-black tracking-tight text-zinc-950 leading-[1.10]">
              Technology &amp; Appliances <br />
              <span className="text-[#00624A]">within your reach</span>
            </h1>

            {/* Subtitle with elegant contrast */}
            <p className="text-sm sm:text-base text-zinc-600 max-w-xl leading-relaxed">
              Discover the latest smartphones, premium home appliances, computers, and sound systems with exceptional quality, manufacturer warranty, and 0% No-Cost EMI financing.
            </p>

            {/* Main Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                onClick={onScrollToCatalog}
                className="inline-flex items-center gap-2.5 px-6 sm:px-8 py-3.5 rounded-xl bg-[#00624A] hover:bg-[#004D3A] text-white text-xs sm:text-sm font-bold shadow-lg shadow-[#00624A]/25 transition-all hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>Discover the collection</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenEmiModal}
                className="inline-flex items-center gap-2 px-5 py-3.5 rounded-xl bg-white hover:bg-[#F6F8F7] border border-zinc-200 text-zinc-800 text-xs sm:text-sm font-bold shadow-2xs transition-all hover:-translate-y-0.5"
              >
                <CreditCard className="w-4 h-4 text-[#00624A]" />
                <span>0% No-Cost EMI</span>
              </button>

              <button
                onClick={onOpenExchangeModal}
                className="inline-flex items-center gap-2 px-4 py-3.5 rounded-xl bg-[#E6F4EE] hover:bg-[#D4EFE4] border border-[#C6E6D8] text-[#00624A] text-xs sm:text-sm font-bold shadow-2xs transition-all hover:-translate-y-0.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Exchange &amp; Save ₹10K</span>
              </button>
            </div>

            {/* 3 Trust Badges matching reference footer of hero:
                "Livraison rapide en 24/48h" · "Paiement sécurisé 100% fiable" · "Service client dédié 7j/7" */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-6 border-t border-zinc-200/80">
              <div className="flex items-center gap-2.5 text-xs font-semibold text-zinc-700">
                <div className="w-9 h-9 rounded-xl bg-[#E6F4EE] text-[#00624A] flex items-center justify-center shrink-0 border border-[#D5ECE1]">
                  <Truck className="w-4 h-4" />
                </div>
                <div>
                  <div className="leading-tight font-bold text-zinc-900">Fast Delivery</div>
                  <div className="text-[11px] text-zinc-400 font-normal">in 24/48 hours</div>
                </div>
              </div>

              <div className="flex items-center gap-2.5 text-xs font-semibold text-zinc-700">
                <div className="w-9 h-9 rounded-xl bg-[#E6F4EE] text-[#00624A] flex items-center justify-center shrink-0 border border-[#D5ECE1]">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <div className="leading-tight font-bold text-zinc-900">100% Reliable</div>
                  <div className="text-[11px] text-zinc-400 font-normal">Secure &amp; 0% EMI</div>
                </div>
              </div>

              <div className="flex items-center gap-2.5 text-xs font-semibold text-zinc-700">
                <div className="w-9 h-9 rounded-xl bg-[#E6F4EE] text-[#00624A] flex items-center justify-center shrink-0 border border-[#D5ECE1]">
                  <Headphones className="w-4 h-4" />
                </div>
                <div>
                  <div className="leading-tight font-bold text-zinc-900">Dedicated Support</div>
                  <div className="text-[11px] text-zinc-400 font-normal">Showroom 7/7</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Ultra-Premium 3D Device Podium Stage */}
          <div
            className="lg:col-span-6 relative"
            onMouseEnter={() => setIsAutoPaused(true)}
            onMouseLeave={() => setIsAutoPaused(false)}
          >
            {/* Main Podium Stage Container */}
            <div className="relative w-full max-w-xl mx-auto aspect-4/3 sm:aspect-16/11 flex items-center justify-center select-none">
              {/* Podium Base Structure with 3D Depth, Ambient Lighting & Gradient */}
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-b from-[#F2F8F5] via-[#E8F3EE] to-[#DCECE5] border border-[#D3E5DE] shadow-inner flex flex-col justify-end p-6 overflow-hidden">
                {/* Upper Soft Light Glow */}
                <div className="absolute top-4 left-1/2 -translate-x-1/2 w-72 h-32 bg-white/70 rounded-full blur-2xl pointer-events-none" />

                {/* 3D Round Pedestal Ring matching reference mockup */}
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-[88%] h-28 rounded-[100%] bg-gradient-to-b from-white via-zinc-50 to-zinc-200/90 shadow-[0_20px_45px_rgba(0,0,0,0.09)] border border-white/90" />
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 w-[94%] h-14 rounded-[100%] bg-[#00624A]/12 blur-xl pointer-events-none" />
              </div>

              {/* Devices positioned on podium with authentic interactive hover */}
              <div
                onClick={() => onSelectCategory(activeSlide.highlightCategory)}
                className="relative z-10 w-full h-full flex items-center justify-center cursor-pointer group"
                title="Click to view this collection in catalog"
              >
                {activeSlide.devices.map((dev, i) => (
                  <div
                    key={i}
                    className={`absolute transition-all duration-700 ease-out transform group-hover:scale-105 ${dev.position}`}
                  >
                    <div className="relative rounded-2xl bg-white/95 p-2.5 sm:p-3 shadow-xl border border-white/90 backdrop-blur-md flex flex-col items-center hover:shadow-2xl transition-shadow">
                      {/* Optional tag */}
                      {dev.tag && (
                        <div className="absolute -top-2 -right-2 bg-[#00624A] text-white text-[9px] font-extrabold px-2 py-0.5 rounded-full shadow-xs">
                          {dev.tag}
                        </div>
                      )}

                      {/* Crisp Product Image */}
                      <div className="w-full aspect-square bg-[#F7FAF8] rounded-xl flex items-center justify-center p-1.5 overflow-hidden">
                        <img
                          src={dev.image}
                          alt={dev.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-contain transition-transform duration-500 hover:scale-110"
                        />
                      </div>

                      {/* Minimal Product Meta */}
                      <div className="mt-2 text-center w-full px-1">
                        <div className="text-[11px] sm:text-xs font-bold text-zinc-900 truncate">
                          {dev.name}
                        </div>
                        <div className="text-[9px] text-zinc-500 truncate font-medium">
                          {dev.specs}
                        </div>
                        <div className="text-[10px] sm:text-xs text-[#00624A] font-extrabold mt-0.5">
                          {dev.price}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Floating Specification Badges with subtle luxury glass styling */}
              <div className="absolute top-4 left-4 z-20 hidden sm:flex items-center gap-1.5 bg-white/90 backdrop-blur-md border border-zinc-200/80 px-2.5 py-1 rounded-xl text-[10px] font-bold text-zinc-800 shadow-xs">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#00624A]" />
                <span>100% Genuine OEM Stock</span>
              </div>

              <div className="absolute top-4 right-4 z-20 hidden sm:flex items-center gap-1.5 bg-[#E6F4EE]/90 backdrop-blur-md border border-[#CDEADA] px-2.5 py-1 rounded-xl text-[10px] font-bold text-[#00624A] shadow-xs">
                <Zap className="w-3.5 h-3.5" />
                <span>0% Down Payment</span>
              </div>

              {/* Carousel Navigation Arrow Buttons matching `<` and `>` in reference mockup */}
              <button
                type="button"
                onClick={handlePrevSlide}
                aria-label="Previous Showcase"
                className="absolute left-2 sm:-left-3.5 top-1/2 -translate-y-1/2 z-30 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/95 hover:bg-white text-zinc-800 border border-zinc-200/90 shadow-lg flex items-center justify-center transition-all hover:scale-105 active:scale-95 hover:text-[#00624A]"
              >
                <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>

              <button
                type="button"
                onClick={handleNextSlide}
                aria-label="Next Showcase"
                className="absolute right-2 sm:-right-3.5 top-1/2 -translate-y-1/2 z-30 w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/95 hover:bg-white text-zinc-800 border border-zinc-200/90 shadow-lg flex items-center justify-center transition-all hover:scale-105 active:scale-95 hover:text-[#00624A]"
              >
                <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>

              {/* Carousel Indicator Dots matching `● ○ ○ ○` in mockup */}
              <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2">
                {SHOWCASE_SLIDES.map((slide, idx) => (
                  <button
                    key={slide.id}
                    onClick={() => setCurrentSlideIndex(idx)}
                    aria-label={`Show slide ${idx + 1}: ${slide.badge}`}
                    className={`h-2.5 rounded-full transition-all duration-300 ${
                      idx === currentSlideIndex
                        ? 'w-7 bg-[#00624A]'
                        : 'w-2.5 bg-[#00624A]/25 hover:bg-[#00624A]/50'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Subtle Title & Subtitle bar below showcase */}
            <div className="text-center mt-3.5 px-2">
              <span className="inline-block text-[11px] sm:text-xs font-bold text-[#00624A] uppercase tracking-wider">
                {activeSlide.badge}:
              </span>{' '}
              <span className="text-[11px] sm:text-xs text-zinc-600 font-medium">
                {activeSlide.title} — {activeSlide.subtitle}
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
