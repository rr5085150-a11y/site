import React, { useState } from 'react';
import { ShoppingBag, Send, PhoneCall, Mail, MapPin, ShieldCheck, CreditCard } from 'lucide-react';
import { GAYATRI_LOGO_URL } from './Navbar';

interface FooterProps {
  onScrollToSection: (id: string) => void;
  onOpenEmiModal: () => void;
  onOpenExchangeModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onScrollToSection,
  onOpenEmiModal,
  onOpenExchangeModal
}) => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [logoError, setLogoError] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 4000);
      setEmail('');
    }
  };

  return (
    <footer className="bg-[#072B23] text-white border-t border-[#0C3D32] pt-14 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Main 4-Column Grid matching reference mockup footer */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Brand Info (col-span-4) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-[#00624A] border border-[#147A60] flex items-center justify-center p-1 shadow-xs overflow-hidden shrink-0">
                {!logoError ? (
                  <img
                    src={GAYATRI_LOGO_URL}
                    alt="Maa Gayatri"
                    className="w-full h-full object-cover rounded-xl"
                    onError={() => setLogoError(true)}
                  />
                ) : (
                  <ShoppingBag className="w-5 h-5 text-emerald-300" />
                )}
              </div>
              <div>
                <span className="text-xl font-extrabold tracking-tight block">Maa Gayatri</span>
                <span className="text-[10px] uppercase font-bold tracking-wider text-[#34D399] block -mt-0.5">
                  Electronics &amp; Appliances
                </span>
              </div>
            </div>

            <p className="text-xs text-zinc-300 leading-relaxed max-w-sm">
              Your trusted authorized showroom for smartphones, 4K OLED TVs, inverter air conditioners, refrigerators, washing machines, and home power backup with 0% No-Cost EMI.
            </p>

            <div className="pt-1 flex items-center gap-2 text-xs text-[#34D399] font-medium">
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>Authorized OEM Brand Invoices &amp; Warranty</span>
            </div>
          </div>

          {/* Useful Links matching "Liens utiles" (col-span-2) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Useful Links
            </h4>
            <ul className="space-y-2 text-xs text-zinc-300">
              <li>
                <button
                  onClick={() => onScrollToSection('hero')}
                  className="hover:text-white transition-colors text-left"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => onScrollToSection('catalog')}
                  className="hover:text-white transition-colors text-left"
                >
                  Shop Catalog
                </button>
              </li>
              <li>
                <button
                  onClick={() => onScrollToSection('categories')}
                  className="hover:text-white transition-colors text-left"
                >
                  Categories
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenEmiModal}
                  className="hover:text-[#34D399] text-[#34D399] font-semibold transition-colors text-left"
                >
                  0% No-Cost EMI
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenExchangeModal}
                  className="hover:text-white transition-colors text-left"
                >
                  Trade-In Valuation
                </button>
              </li>
              <li>
                <button
                  onClick={() => onScrollToSection('trust-proof')}
                  className="hover:text-white transition-colors text-left"
                >
                  About &amp; Reviews
                </button>
              </li>
            </ul>
          </div>

          {/* Follow Us / Social Links matching "Suivez-nous" (col-span-2) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Follow Us
            </h4>
            <div className="flex items-center gap-3 pt-1">
              {/* Facebook */}
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#0D382E] hover:bg-[#00624A] text-white flex items-center justify-center transition-colors shadow-2xs"
                aria-label="Facebook"
              >
                <span className="font-bold text-xs">f</span>
              </a>
              {/* Instagram */}
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#0D382E] hover:bg-[#00624A] text-white flex items-center justify-center transition-colors shadow-2xs"
                aria-label="Instagram"
              >
                <span className="font-bold text-xs">in</span>
              </a>
              {/* YouTube */}
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#0D382E] hover:bg-[#00624A] text-white flex items-center justify-center transition-colors shadow-2xs"
                aria-label="YouTube"
              >
                <span className="font-bold text-xs">yt</span>
              </a>
              {/* WhatsApp */}
              <a
                href="https://wa.me/919826054321"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#00624A] hover:bg-emerald-600 text-white flex items-center justify-center transition-colors shadow-2xs"
                aria-label="WhatsApp"
              >
                <span className="font-bold text-xs">wa</span>
              </a>
            </div>

            <div className="pt-3 text-[11px] text-zinc-400 space-y-1">
              <div>Helpline: +91 98260 54321</div>
              <div>Showroom Open 7 Days: 10AM - 9PM</div>
            </div>
          </div>

          {/* Newsletter Box matching reference mockup (col-span-4) */}
          <div className="lg:col-span-4 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Newsletter
            </h4>
            <p className="text-xs text-zinc-300">
              Receive our newest arrivals, launch discounts, and exclusive 0% EMI festive offers.
            </p>

            <form onSubmit={handleSubscribe} className="relative mt-2">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                required
                className="w-full pl-4 pr-12 py-2.5 rounded-full bg-white text-zinc-900 text-xs focus:outline-hidden placeholder:text-zinc-400 font-medium"
              />
              <button
                type="submit"
                aria-label="Subscribe"
                className="absolute right-1 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-[#00624A] hover:bg-[#004D3A] text-white flex items-center justify-center transition-colors shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>

            {subscribed && (
              <p className="text-xs text-[#34D399] font-medium pt-1">
                Thank you! You are now subscribed to exclusive VIP tech alerts.
              </p>
            )}
          </div>
        </div>

        {/* Bottom Copyright & Policy Strip matching mockup */}
        <div className="pt-8 border-t border-[#0D382E] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-400">
          <div>
            &copy; 2026 Maa Gayatri Electronics. All rights reserved.
          </div>
          <div className="flex items-center gap-6 text-[11px]">
            <a href="#hero" className="hover:text-white transition-colors">
              Terms &amp; Conditions
            </a>
            <span className="text-zinc-700">·</span>
            <a href="#hero" className="hover:text-white transition-colors">
              Privacy Policy
            </a>
            <span className="text-zinc-700">·</span>
            <a href="#hero" className="hover:text-white transition-colors">
              Security &amp; Invoices
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};
