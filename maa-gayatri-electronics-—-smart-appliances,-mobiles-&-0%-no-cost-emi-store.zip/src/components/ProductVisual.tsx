import React, { useState } from 'react';

interface ProductVisualProps {
  type: 'ac' | 'tv' | 'fridge' | 'washing' | 'mobiles' | 'inverter' | 'kitchen' | 'battery';
  name: string;
  imageUrl?: string;
  className?: string;
  highlightText?: string;
}

export const ProductVisual: React.FC<ProductVisualProps> = ({
  type,
  name,
  imageUrl,
  className = '',
  highlightText
}) => {
  const [imageError, setImageError] = useState(false);

  return (
    <div
      className={`relative w-full h-full flex items-center justify-center overflow-hidden bg-[#F6F8F7] select-none ${className}`}
      aria-label={name}
    >
      {/* If an imageUrl is provided and valid, show the real photography */}
      {imageUrl && !imageError ? (
        <img
          src={imageUrl}
          alt={name}
          referrerPolicy="no-referrer"
          onError={() => setImageError(true)}
          className="w-full h-full object-contain p-2.5 sm:p-3 transition-transform duration-500 group-hover:scale-105 drop-shadow-xs"
        />
      ) : (
        <div className="relative w-full h-full flex items-center justify-center p-6">
          {/* Subtle background ambient ring */}
          <div className="absolute inset-0 bg-[radial-gradient(#e4e4e7_1px,transparent_1px)] [background-size:16px_16px] opacity-40 pointer-events-none" />

          {/* AC Visual */}
          {type === 'ac' && (
            <div className="relative w-full max-w-[280px] h-[170px] flex items-center justify-center">
              <div className="relative w-full h-[88px] bg-white rounded-xl shadow-[0_12px_32px_rgba(0,0,0,0.06),0_2px_6px_rgba(0,0,0,0.04)] border border-zinc-200/90 flex flex-col justify-between p-2.5 overflow-hidden">
                <div className="w-full flex justify-between gap-1 px-2 pt-1 opacity-40">
                  <div className="h-0.5 flex-1 bg-zinc-300 rounded-full" />
                  <div className="h-0.5 flex-1 bg-zinc-300 rounded-full" />
                  <div className="h-0.5 flex-1 bg-zinc-300 rounded-full" />
                  <div className="h-0.5 flex-1 bg-zinc-300 rounded-full" />
                </div>
                <div className="flex items-center justify-between px-3">
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-zinc-400/80" />
                    <span className="text-[10px] font-semibold tracking-wider text-zinc-500 uppercase">
                      MAA GAYATRI
                    </span>
                  </div>
                  <div className="flex items-baseline gap-0.5 bg-zinc-900 text-white px-2 py-0.5 rounded text-[11px] font-mono font-medium shadow-inner">
                    <span>18</span>
                    <span className="text-[8px] text-zinc-400">°C</span>
                  </div>
                </div>
                <div className="relative w-full h-4 bg-zinc-50 rounded border-t border-zinc-200/90 flex items-center px-3 justify-between">
                  <div className="w-12 h-1 bg-blue-500/80 rounded-full" />
                  <div className="flex gap-1.5 items-center">
                    <span className="text-[9px] text-zinc-400 font-mono">5★ INVERTER</span>
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TV Visual */}
          {type === 'tv' && (
            <div className="relative w-full max-w-[280px] h-[170px] flex flex-col items-center justify-center">
              <div className="relative w-full h-[126px] bg-zinc-950 rounded-lg p-1 shadow-[0_16px_36px_rgba(0,0,0,0.12),0_2px_8px_rgba(0,0,0,0.08)] border border-zinc-800 flex flex-col justify-between overflow-hidden">
                <div className="relative w-full h-full rounded bg-gradient-to-tr from-zinc-900 via-indigo-950 to-slate-900 overflow-hidden flex flex-col justify-between p-2.5">
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] font-mono tracking-widest text-indigo-300 uppercase">
                      4K CINEMA · 120HZ
                    </span>
                    <span className="text-[9px] text-zinc-400 font-mono">DOLBY ATMOS</span>
                  </div>
                  <div className="relative w-full h-8 flex items-center justify-center overflow-hidden">
                    <div className="w-24 h-24 rounded-full bg-gradient-to-r from-indigo-500 via-purple-500 to-cyan-400 blur-md opacity-70" />
                  </div>
                  <div className="flex justify-between items-center text-[9px] text-zinc-300">
                    <span className="font-medium">Sony / Samsung Panel</span>
                    <span className="text-emerald-400 font-mono">0% EMI</span>
                  </div>
                </div>
              </div>
              <div className="w-16 h-2 bg-gradient-to-r from-zinc-400 via-zinc-200 to-zinc-400 rounded-b shadow" />
            </div>
          )}

          {/* Refrigerator Visual */}
          {type === 'fridge' && (
            <div className="relative w-full max-w-[220px] h-[170px] flex items-center justify-center">
              <div className="relative w-36 h-[150px] bg-zinc-200 rounded-xl shadow-[0_12px_28px_rgba(0,0,0,0.08)] border border-zinc-300/90 flex flex-col overflow-hidden">
                <div className="flex-1 flex border-b-2 border-zinc-300 bg-gradient-to-b from-zinc-100 to-zinc-200">
                  <div className="flex-1 border-r border-zinc-300 p-2 flex flex-col justify-between">
                    <div className="w-full h-9 bg-zinc-900 rounded p-1 flex flex-col justify-between shadow-inner">
                      <div className="flex justify-between text-[7px] text-zinc-400 font-mono">
                        <span>FRIDGE</span>
                        <span className="text-emerald-400">2°C</span>
                      </div>
                      <div className="flex justify-between text-[7px] text-zinc-400 font-mono">
                        <span>FREEZE</span>
                        <span className="text-cyan-400">-18°C</span>
                      </div>
                    </div>
                    <div className="w-1 h-6 bg-zinc-400/60 rounded-full self-end" />
                  </div>
                  <div className="flex-1 p-2 flex flex-col justify-between">
                    <span className="text-[7px] font-semibold text-zinc-500 tracking-wider">BESPOKE</span>
                    <div className="w-1 h-6 bg-zinc-400/60 rounded-full self-start" />
                  </div>
                </div>
                <div className="h-12 bg-gradient-to-b from-zinc-100 to-zinc-200 p-2 flex items-center justify-center">
                  <div className="w-16 h-1.5 bg-zinc-400/70 rounded-full shadow-inner" />
                </div>
              </div>
            </div>
          )}

          {/* Washing Machine Visual */}
          {type === 'washing' && (
            <div className="relative w-full max-w-[220px] h-[170px] flex items-center justify-center">
              <div className="relative w-32 h-[145px] bg-white rounded-2xl shadow-[0_12px_28px_rgba(0,0,0,0.08)] border border-zinc-300 flex flex-col p-2.5 justify-between overflow-hidden">
                {/* Control Panel */}
                <div className="w-full h-7 bg-zinc-100 rounded-lg p-1.5 flex items-center justify-between border border-zinc-200">
                  <div className="w-3.5 h-3.5 rounded-full border-2 border-zinc-400 flex items-center justify-center">
                    <div className="w-1 h-1 rounded-full bg-blue-600" />
                  </div>
                  <div className="flex items-center gap-1 font-mono text-[8px] bg-zinc-900 text-emerald-400 px-1.5 py-0.5 rounded">
                    <span>1200 RPM</span>
                  </div>
                </div>

                {/* Round Front-Load Glass Door */}
                <div className="w-20 h-20 rounded-full mx-auto bg-zinc-900 border-4 border-zinc-300 flex items-center justify-center shadow-inner relative overflow-hidden">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-slate-900 via-blue-950 to-indigo-900 flex items-center justify-center border border-zinc-700">
                    <div className="w-6 h-6 rounded-full border border-blue-400/40 opacity-70" />
                  </div>
                  {/* Glass glare */}
                  <div className="absolute top-1 left-2 w-6 h-3 bg-white/30 rounded-full rotate-45 blur-xs" />
                </div>

                <div className="flex justify-between items-center text-[7px] font-mono text-zinc-500">
                  <span>AI DIRECT DRIVE</span>
                  <span className="text-blue-600 font-bold">8.0 KG</span>
                </div>
              </div>
            </div>
          )}

          {/* Smartphone & Battery Visual */}
          {(type === 'mobiles' || type === 'battery') && (
            <div className="relative w-full max-w-[240px] h-[170px] flex items-center justify-center">
              {/* Modern Smartphone Silhouette */}
              <div className="relative w-24 h-[145px] bg-zinc-950 rounded-2xl p-1.5 shadow-[0_12px_32px_rgba(0,0,0,0.14)] border border-zinc-800 flex flex-col justify-between">
                {/* Dynamic island notch */}
                <div className="w-8 h-2 bg-zinc-900 rounded-full mx-auto" />

                {/* Screen Wallpaper */}
                <div className="w-full flex-1 rounded-xl bg-gradient-to-br from-zinc-900 via-blue-950 to-zinc-900 my-1 p-2 flex flex-col justify-between border border-zinc-800">
                  <span className="text-[7px] text-zinc-400 font-mono">5G · 120Hz</span>
                  <div className="text-center">
                    <span className="text-[10px] font-bold text-white block">iPhone / Galaxy</span>
                    <span className="text-[7px] text-emerald-400 font-mono">100% HEALTH BATTERY</span>
                  </div>
                  <div className="flex justify-between text-[7px] text-zinc-400 font-mono">
                    <span>256GB</span>
                    <span className="text-blue-400">0% EMI</span>
                  </div>
                </div>

                <div className="w-8 h-1 bg-zinc-700 rounded-full mx-auto" />
              </div>
            </div>
          )}

          {/* Inverter & Solar Battery Visual */}
          {type === 'inverter' && (
            <div className="relative w-full max-w-[240px] h-[170px] flex items-center justify-center">
              <div className="relative w-40 h-[135px] flex flex-col justify-between">
                {/* Pure Sinewave Inverter Unit */}
                <div className="w-full h-14 bg-zinc-900 rounded-xl p-2 border border-zinc-800 shadow flex items-center justify-between text-white">
                  <div className="space-y-0.5">
                    <span className="text-[8px] font-bold text-zinc-300 block">SINEWAVE INVERTER</span>
                    <span className="text-[7px] text-emerald-400 font-mono">MAINS ON · ECO MODE</span>
                  </div>
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-500 flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  </div>
                </div>

                {/* Heavy Tubular Battery */}
                <div className="w-full h-16 bg-red-700 rounded-xl p-2 border border-red-800 shadow flex items-center justify-between text-white">
                  <div className="space-y-0.5">
                    <span className="text-[9px] font-extrabold text-white">150AH TUBULAR BATTERY</span>
                    <span className="text-[7px] text-red-200">60-Month Warranty · Heavy Duty</span>
                  </div>
                  <div className="flex gap-1">
                    <div className="w-2 h-3 bg-zinc-300 rounded-t" />
                    <div className="w-2 h-3 bg-zinc-300 rounded-t" />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Kitchen Appliance (Microwave / RO) */}
          {type === 'kitchen' && (
            <div className="relative w-full max-w-[240px] h-[170px] flex items-center justify-center">
              <div className="relative w-36 h-[115px] bg-zinc-900 rounded-xl p-2.5 border border-zinc-800 shadow flex justify-between">
                {/* Oven Glass Window */}
                <div className="flex-1 rounded-lg bg-zinc-950 border border-zinc-800 mr-2 flex items-center justify-center relative overflow-hidden">
                  <div className="w-10 h-10 rounded-full border border-amber-500/30 bg-amber-500/10 flex items-center justify-center">
                    <div className="w-4 h-4 rounded-full bg-amber-400/60 blur-xs" />
                  </div>
                </div>
                {/* Touch Control Strip */}
                <div className="w-8 flex flex-col justify-between py-1 text-center">
                  <div className="bg-emerald-950 text-emerald-400 text-[8px] font-mono rounded py-0.5 border border-emerald-800">
                    01:30
                  </div>
                  <div className="w-4 h-4 rounded-full border border-zinc-600 mx-auto" />
                  <div className="w-5 h-2 bg-zinc-800 rounded mx-auto" />
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Floating subtle badge */}
      {highlightText && (
        <div className="absolute bottom-3 right-3 text-[11px] font-medium text-zinc-700 bg-white/90 backdrop-blur-sm px-2.5 py-1 rounded-md border border-zinc-200/80 shadow-xs pointer-events-none">
          {highlightText}
        </div>
      )}
    </div>
  );
};
