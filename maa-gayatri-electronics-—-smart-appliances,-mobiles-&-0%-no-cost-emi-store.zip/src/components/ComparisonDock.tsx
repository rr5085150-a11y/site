import React from 'react';
import { Scale, X, ArrowRight } from 'lucide-react';
import { ProductItem } from '../types/tech';

interface ComparisonDockProps {
  comparedProducts: ProductItem[];
  onRemove: (productId: string) => void;
  onClear: () => void;
  onOpenModal: () => void;
}

export const ComparisonDock: React.FC<ComparisonDockProps> = ({
  comparedProducts,
  onRemove,
  onClear,
  onOpenModal
}) => {
  if (comparedProducts.length === 0) return null;

  return (
    <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-30 max-w-2xl w-[92%] sm:w-auto bg-zinc-950/95 text-white backdrop-blur-md px-4 py-3 rounded-2xl shadow-[0_20px_40px_rgba(0,0,0,0.3)] border border-zinc-800 flex items-center justify-between gap-4 transition-all animate-in fade-in slide-in-from-bottom-4">
      {/* Items list */}
      <div className="flex items-center gap-2 overflow-x-auto py-0.5 max-w-[320px] sm:max-w-[420px]">
        <div className="hidden sm:flex items-center gap-1.5 text-xs text-zinc-400 font-medium shrink-0 mr-1">
          <Scale className="w-4 h-4 text-white" />
          <span>Compare:</span>
        </div>

        {comparedProducts.map((p) => (
          <div
            key={p.id}
            className="flex items-center gap-1.5 bg-zinc-800/90 hover:bg-zinc-800 px-2.5 py-1 rounded-lg text-xs shrink-0 border border-zinc-700/60"
          >
            <span className="font-medium text-white max-w-[110px] truncate">{p.name}</span>
            <button
              onClick={() => onRemove(p.id)}
              className="text-zinc-400 hover:text-white p-0.5 rounded transition-colors"
              title="Remove"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={onClear}
          className="text-xs text-zinc-400 hover:text-white px-2 py-1 transition-colors"
        >
          Clear
        </button>

        <button
          onClick={onOpenModal}
          className="px-3.5 py-1.5 bg-white text-zinc-950 hover:bg-zinc-100 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs shrink-0"
        >
          <span>Compare Specs ({comparedProducts.length})</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
