import React from 'react';
import { BatteryCharging, ShieldCheck, CheckCircle2, Zap, ArrowRight, Gauge, Wrench } from 'lucide-react';
import { ProductItem } from '../types/tech';

interface BatteryFocusSectionProps {
  batteryProducts: ProductItem[];
  onBookBattery: (product: ProductItem) => void;
  onViewSpecs: (product: ProductItem) => void;
}

export const BatteryFocusSection: React.FC<BatteryFocusSectionProps> = ({
  batteryProducts,
  onBookBattery,
  onViewSpecs
}) => {
  return (
    <section id="battery-focus" className="py-16 md:py-24 bg-white border-b border-zinc-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Explanatory Proof & Guarantees */}
          <div className="lg:col-span-6 space-y-6">
            <div className="text-xs font-bold uppercase tracking-wider text-emerald-600 flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-emerald-600" />
              <span>Maa Gayatri Certified Smartphone &amp; Battery Lab</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-extrabold text-zinc-950 tracking-tight leading-tight">
              Restore 100% Smartphone Battery Health in 30 Minutes.
            </h2>

            <p className="text-zinc-600 text-sm sm:text-base leading-relaxed">
              Don’t let cheap duplicate batteries swell up or trigger iOS / Android "Unknown Part" warnings. Our certified replacements use 100% brand-new, zero-cycle cobalt cells with original BMS microcontroller chips.
            </p>

            <div className="space-y-3 pt-2">
              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-zinc-900">Guaranteed 100% Maximum Capacity</h4>
                  <p className="text-xs text-zinc-500">
                    Calibrated directly to your phone's power management IC for flawless day-one battery life.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-zinc-900">Factory IP68 Waterproof Seal Restored</h4>
                  <p className="text-xs text-zinc-500">
                    We never leave your phone unsealed. Every swap includes fresh laser-cut waterproof adhesive gaskets.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-zinc-900">365-Day No-Questions Replacement Warranty</h4>
                  <p className="text-xs text-zinc-500">
                    Any sudden voltage drops, swelling, or rapid battery drain within 1 year gets an instant free replacement.
                  </p>
                </div>
              </div>
            </div>

            {/* Quick interactive test stats */}
            <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-200/80 grid grid-cols-3 gap-3 text-center">
              <div>
                <span className="block text-xl font-extrabold text-zinc-950 font-mono tabular-nums">800+</span>
                <span className="text-[11px] text-zinc-500">Charge Cycles</span>
              </div>
              <div className="border-x border-zinc-200">
                <span className="block text-xl font-extrabold text-emerald-600 font-mono tabular-nums">30 Min</span>
                <span className="text-[11px] text-zinc-500">On-Spot Swap</span>
              </div>
              <div>
                <span className="block text-xl font-extrabold text-blue-600 font-mono tabular-nums">100%</span>
                <span className="text-[11px] text-zinc-500">Health Readout</span>
              </div>
            </div>
          </div>

          {/* Right Column: Featured Battery Swap Packages with High-Res Imagery */}
          <div className="lg:col-span-6 space-y-4">
            {batteryProducts.map((batt) => (
              <div
                key={batt.id}
                className="p-5 sm:p-6 bg-white hover:bg-[#F9FCFA] rounded-3xl border border-[#E4ECE7] hover:border-[#C3DAD0] transition-all space-y-4 shadow-sm hover:shadow-md"
              >
                <div className="flex flex-col sm:flex-row sm:items-start gap-4">
                  {/* High-Resolution Thumbnail */}
                  <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-[#F6F8F7] border border-zinc-200/80 p-2 shrink-0 flex items-center justify-center overflow-hidden">
                    <img
                      src={batt.imageUrl || 'https://images.unsplash.com/photo-1588508065123-287b28e013da?auto=format&fit=crop&w=400&q=80'}
                      alt={batt.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain transition-transform duration-300 hover:scale-110"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-bold text-[#00624A] uppercase tracking-wider bg-[#E6F4EE] px-2 py-0.5 rounded-md">
                          {batt.brand}
                        </span>
                        <h3 className="text-sm sm:text-base font-bold text-zinc-950 mt-1 line-clamp-1">
                          {batt.name}
                        </h3>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-lg sm:text-xl font-black text-zinc-950 tabular-nums">
                          ₹{batt.price.toLocaleString('en-IN')}
                        </span>
                        <span className="block text-[10px] text-[#00624A] font-semibold">
                          Doorstep Tech Included
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-zinc-500 mt-1.5 line-clamp-2 leading-relaxed">
                      {batt.tagline}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs text-zinc-600 pt-2 border-t border-zinc-100">
                  <div className="flex items-center gap-1.5">
                    <Gauge className="w-3.5 h-3.5 text-zinc-400" />
                    <span className="text-[11px] font-medium">800+ Cycles Guaranteed</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#00624A]" />
                    <span className="text-[11px] font-medium">1-Year Full Warranty</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 pt-1">
                  <button
                    onClick={() => onBookBattery(batt)}
                    className="flex-1 py-2.5 px-4 bg-[#00624A] hover:bg-[#004D3A] text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-[#00624A]/20 flex items-center justify-center gap-2"
                  >
                    <Wrench className="w-3.5 h-3.5" />
                    <span>Book 30-Min Doorstep Swap</span>
                  </button>

                  <button
                    onClick={() => onViewSpecs(batt)}
                    className="py-2.5 px-4 bg-[#F6F8F7] hover:bg-zinc-100 text-zinc-800 border border-zinc-200/90 rounded-xl text-xs font-bold transition-colors"
                  >
                    Inspect Specs
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
