import React from 'react';
import { Smartphone, Laptop, Headphones, Watch, Tv, Wind, Refrigerator, Zap, ArrowRight } from 'lucide-react';
import { TechCategory } from '../types/tech';

interface CategoryItem {
  id: TechCategory | string;
  mappedCategory: TechCategory;
  name: string;
  imageUrl: string;
  count: string;
  icon: React.ElementType;
}

interface BrowseByCategoryProps {
  selectedCategory: TechCategory;
  onSelectCategory: (category: TechCategory) => void;
  onViewAll?: () => void;
}

const CATEGORIES: CategoryItem[] = [
  {
    id: 'smartphones',
    mappedCategory: 'mobiles',
    name: 'Smartphones',
    imageUrl: 'https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=500&q=80',
    count: '18 Models',
    icon: Smartphone
  },
  {
    id: 'computers',
    mappedCategory: 'mobiles',
    name: 'Computers',
    imageUrl: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=500&q=80',
    count: '12 Models',
    icon: Laptop
  },
  {
    id: 'audio',
    mappedCategory: 'mobiles',
    name: 'Audio',
    imageUrl: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=500&q=80',
    count: '14 Models',
    icon: Headphones
  },
  {
    id: 'smartwatches',
    mappedCategory: 'mobiles',
    name: 'Smartwatches',
    imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=500&q=80',
    count: '8 Models',
    icon: Watch
  },
  {
    id: 'gaming_tvs',
    mappedCategory: 'tv',
    name: 'Gaming & TVs',
    imageUrl: 'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?auto=format&fit=crop&w=500&q=80',
    count: '16 Models',
    icon: Tv
  },
  {
    id: 'air_conditioners',
    mappedCategory: 'ac',
    name: 'Air Conditioners',
    imageUrl: 'https://images.unsplash.com/photo-1614633833026-06204c6a6f69?auto=format&fit=crop&w=500&q=80',
    count: '10 Models',
    icon: Wind
  },
  {
    id: 'refrigerators',
    mappedCategory: 'fridge',
    name: 'Refrigerators',
    imageUrl: 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?auto=format&fit=crop&w=500&q=80',
    count: '9 Models',
    icon: Refrigerator
  },
  {
    id: 'inverters',
    mappedCategory: 'inverter',
    name: 'Inverters',
    imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=500&q=80',
    count: '6 Sets',
    icon: Zap
  }
];

export const BrowseByCategory: React.FC<BrowseByCategoryProps> = ({
  selectedCategory,
  onSelectCategory,
  onViewAll
}) => {
  return (
    <section className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
      {/* Header line matching "NOS CATÉGORIES / Parcourir par catégorie" */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="w-6 h-0.5 bg-[#00624A]" />
            <span className="text-[11px] sm:text-xs font-bold uppercase tracking-wider text-[#00624A]">
              Our Categories
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-zinc-950 tracking-tight">
            Browse by Category
          </h2>
        </div>

        <button
          onClick={onViewAll}
          className="group inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-[#00624A] hover:text-[#004D3A] transition-colors"
        >
          <span>View all categories</span>
          <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
        </button>
      </div>

      {/* Grid of rounded cards matching the reference */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4">
        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat.mappedCategory;
          const Icon = cat.icon;

          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.mappedCategory)}
              className={`group flex flex-col items-center text-center p-3 sm:p-3.5 rounded-2xl transition-all duration-300 ${
                isSelected
                  ? 'bg-white border-2 border-[#00624A] shadow-md shadow-[#00624A]/10 -translate-y-1'
                  : 'bg-[#F6F8F7] hover:bg-[#EEF4F1] border border-[#E9EFEB] hover:shadow-sm hover:-translate-y-0.5'
              }`}
            >
              {/* Product Visual Container with soft white background and rounded pill */}
              <div className="relative w-full aspect-square rounded-xl bg-white flex items-center justify-center p-3 mb-3 overflow-hidden shadow-2xs group-hover:shadow-xs transition-shadow">
                <img
                  src={cat.imageUrl}
                  alt={cat.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain transition-transform duration-300 group-hover:scale-110"
                  onError={(e) => {
                    // Fallback to Icon if image doesn't load
                    (e.target as HTMLElement).style.display = 'none';
                    const parent = (e.target as HTMLElement).parentElement;
                    if (parent) {
                      const iconEl = parent.querySelector('.fallback-icon');
                      if (iconEl) iconEl.classList.remove('hidden');
                    }
                  }}
                />
                <div className="fallback-icon hidden w-full h-full flex items-center justify-center text-[#00624A]">
                  <Icon className="w-8 h-8" />
                </div>
              </div>

              {/* Title & Count */}
              <span className={`text-xs sm:text-sm font-bold tracking-tight transition-colors truncate max-w-full ${
                isSelected ? 'text-[#00624A]' : 'text-zinc-900 group-hover:text-[#00624A]'
              }`}>
                {cat.name}
              </span>
              <span className="text-[10px] text-zinc-400 mt-0.5 font-medium">
                {cat.count}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
};
