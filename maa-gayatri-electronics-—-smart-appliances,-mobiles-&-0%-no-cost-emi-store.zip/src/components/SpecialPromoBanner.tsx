import React from 'react';
import { ArrowRight, Sparkles, Tag, ShieldCheck } from 'lucide-react';

interface SpecialPromoBannerProps {
  onExploreOffers: () => void;
  onOpenEmiModal: () => void;
}

export const SpecialPromoBanner: React.FC<SpecialPromoBannerProps> = ({
  onExploreOffers,
  onOpenEmiModal
}) => {
  return (
    <section className="py-8 sm:py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-[#D6EDE4] via-[#E2F3ED] to-[#EBF6F1] border border-[#CDE5DB] shadow-sm">
        {/* Subtle decorative leaf and glow accents */}
        <div className="absolute -top-12 -left-12 w-48 h-48 rounded-full bg-white/40 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-16 right-1/3 w-64 h-64 rounded-full bg-[#00624A]/10 blur-3xl pointer-events-none" />

        <div className="relative grid grid-cols-1 lg:grid-cols-12 items-center gap-8 p-6 sm:p-10 lg:p-12">
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-4 sm:space-y-5 z-10">
            {/* Pill badge */}
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/80 backdrop-blur-xs border border-[#C2E3D6] text-xs font-bold text-[#00624A] shadow-2xs">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Special Offer · Limited Time</span>
            </div>

            {/* Display Headline */}
            <h3 className="text-2xl sm:text-4xl lg:text-[42px] font-extrabold text-zinc-950 tracking-tight leading-[1.15]">
              Up to <span className="text-[#00624A] font-black">25% Off</span> <br className="hidden sm:inline" />
              on Selected Electronics &amp; Appliances
            </h3>

            {/* Subtitle */}
            <p className="text-xs sm:text-sm md:text-base text-zinc-600 max-w-xl leading-relaxed">
              Equip your home with the finest brands and take advantage of our exclusive 0% No-Cost EMI financing with zero down payment and same-day delivery!
            </p>

            {/* Action buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onExploreOffers}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#00624A] hover:bg-[#004D3A] text-white text-xs sm:text-sm font-bold shadow-md shadow-[#00624A]/20 transition-all hover:-translate-y-0.5 active:translate-y-0"
              >
                <span>View Special Offers</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onOpenEmiModal}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-white/90 hover:bg-white text-zinc-900 border border-[#CDE5DB] text-xs sm:text-sm font-bold shadow-2xs transition-all hover:-translate-y-0.5"
              >
                <Tag className="w-3.5 h-3.5 text-[#00624A]" />
                <span>Calculate 0% EMI</span>
              </button>
            </div>

            {/* Trust points */}
            <div className="flex items-center gap-4 pt-2 text-[11px] sm:text-xs text-zinc-600 font-medium">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-[#00624A]" />
                <span>100% Brand Warranty</span>
              </div>
              <span className="text-zinc-300">·</span>
              <div>Bajaj Finserv &amp; Bank Cards</div>
              <span className="text-zinc-300">·</span>
              <div>Free Doorstep Setup</div>
            </div>
          </div>

          {/* Right Product Showcase on Tabletop/Pedestal matching reference layout */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            <div className="relative w-full max-w-md aspect-4/3 rounded-3xl bg-gradient-to-b from-white/90 to-[#EAF4F0]/80 backdrop-blur-md p-4 sm:p-6 border border-white/90 shadow-lg flex items-center justify-center overflow-hidden group">
              {/* Soft ambient green glow */}
              <div className="absolute -bottom-10 right-0 w-44 h-44 rounded-full bg-[#00624A]/10 blur-2xl pointer-events-none" />

              {/* Multi-Device Layout */}
              <div className="relative w-full h-full flex items-center justify-center">
                {/* Laptop centered */}
                <img
                  src="https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=600&q=80"
                  alt="MacBook Pro"
                  referrerPolicy="no-referrer"
                  className="w-48 sm:w-56 object-contain z-10 transition-transform duration-500 group-hover:scale-105"
                />

                {/* Smartphone standing next to laptop */}
                <div className="absolute right-2 sm:right-4 bottom-2 z-20 w-16 sm:w-20 rounded-xl bg-white/90 p-1 shadow-md border border-white/80 transition-transform duration-500 group-hover:translate-x-1">
                  <img
                    src="https://images.unsplash.com/photo-1592750475338-74b7b21085ab?auto=format&fit=crop&w=300&q=80"
                    alt="Smartphone"
                    referrerPolicy="no-referrer"
                    className="w-full aspect-square object-contain"
                  />
                </div>

                {/* Headphones */}
                <div className="absolute left-2 sm:left-4 bottom-2 z-20 w-16 sm:w-20 rounded-xl bg-white/90 p-1 shadow-md border border-white/80 transition-transform duration-500 group-hover:-translate-x-1">
                  <img
                    src="https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=300&q=80"
                    alt="Headphones"
                    referrerPolicy="no-referrer"
                    className="w-full aspect-square object-contain"
                  />
                </div>
              </div>

              {/* Floating Sale Tag */}
              <div className="absolute top-3 left-3 bg-[#00624A] text-white text-[11px] font-black px-3 py-1 rounded-full shadow-sm">
                Save Up to 25% Off
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
