import React, { useState } from 'react';
import { X, RefreshCw, CheckCircle2, ArrowRight, ShieldCheck } from 'lucide-react';

interface OldApplianceExchangeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyExchange: (deviceName: string, discountAmount: number) => void;
}

export const OldApplianceExchangeModal: React.FC<OldApplianceExchangeModalProps> = ({
  isOpen,
  onClose,
  onApplyExchange
}) => {
  const [selectedType, setSelectedType] = useState<string>('ac');
  const [brand, setBrand] = useState<string>('LG');
  const [condition, setCondition] = useState<'working' | 'minor_issue' | 'not_working'>('working');

  if (!isOpen) return null;

  const applianceTypes = [
    { id: 'ac', label: 'Old Split / Window AC', baseValue: 6500 },
    { id: 'tv', label: 'Old LED / LCD TV', baseValue: 4200 },
    { id: 'fridge', label: 'Old Refrigerator', baseValue: 4800 },
    { id: 'washing', label: 'Old Washing Machine', baseValue: 3500 },
    { id: 'mobiles', label: 'Old Smartphone', baseValue: 5000 }
  ];

  const currentType = applianceTypes.find((t) => t.id === selectedType) || applianceTypes[0];

  let multiplier = 1.0;
  if (condition === 'minor_issue') multiplier = 0.75;
  if (condition === 'not_working') multiplier = 0.45;

  const estimatedValue = Math.round(currentType.baseValue * multiplier);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-zinc-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-zinc-200/80 flex items-center justify-between bg-zinc-50">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-600 text-white rounded-xl">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                Maa Gayatri Trade-In Program
              </span>
              <h2 className="text-lg font-extrabold text-zinc-950">
                Old Appliance Exchange Valuation
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-zinc-900 rounded-full hover:bg-zinc-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5 overflow-y-auto">
          <div>
            <label className="text-xs font-bold text-zinc-700 uppercase tracking-wider block mb-2">
              Select Old Appliance to Trade-In:
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {applianceTypes.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setSelectedType(item.id)}
                  className={`p-3 rounded-xl border text-left font-semibold transition-all ${
                    selectedType === item.id
                      ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 shadow-xs'
                      : 'border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-700'
                  }`}
                >
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-700 uppercase tracking-wider block mb-1">
              Existing Brand:
            </label>
            <input
              type="text"
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              placeholder="e.g. LG, Samsung, Sony, Whirlpool, Daikin"
              className="w-full text-xs p-3 bg-zinc-50 border border-zinc-300 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-zinc-950"
            />
          </div>

          <div>
            <label className="text-xs font-bold text-zinc-700 uppercase tracking-wider block mb-2">
              Operating Condition:
            </label>
            <div className="grid grid-cols-3 gap-2 text-xs">
              <button
                onClick={() => setCondition('working')}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  condition === 'working'
                    ? 'border-zinc-950 bg-zinc-950 text-white font-bold'
                    : 'border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-700'
                }`}
              >
                Fully Functional
              </button>
              <button
                onClick={() => setCondition('minor_issue')}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  condition === 'minor_issue'
                    ? 'border-zinc-950 bg-zinc-950 text-white font-bold'
                    : 'border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-700'
                }`}
              >
                Minor Defect
              </button>
              <button
                onClick={() => setCondition('not_working')}
                className={`p-2.5 rounded-xl border text-center transition-all ${
                  condition === 'not_working'
                    ? 'border-zinc-950 bg-zinc-950 text-white font-bold'
                    : 'border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-700'
                }`}
              >
                Non-Working Scrap
              </button>
            </div>
          </div>

          {/* Value output */}
          <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-emerald-800 uppercase block">
                Guaranteed Exchange Discount
              </span>
              <span className="text-2xl font-extrabold text-emerald-950 font-mono tabular-nums">
                ₹{estimatedValue.toLocaleString('en-IN')}
              </span>
              <span className="text-[11px] text-emerald-700 block mt-0.5">
                Deducted immediately at doorstep pickup
              </span>
            </div>
            <div className="w-12 h-12 rounded-full bg-emerald-200 flex items-center justify-center text-emerald-800">
              <ShieldCheck className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-zinc-50 border-t border-zinc-200/80 flex items-center justify-end">
          <button
            onClick={() => {
              onApplyExchange(`${brand} ${currentType.label}`, estimatedValue);
              onClose();
            }}
            className="w-full py-3 bg-zinc-950 hover:bg-zinc-800 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2"
          >
            <span>Apply ₹{estimatedValue.toLocaleString('en-IN')} Discount to Order</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
