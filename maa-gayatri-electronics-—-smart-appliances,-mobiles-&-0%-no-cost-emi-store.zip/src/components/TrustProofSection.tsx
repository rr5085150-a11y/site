import React from 'react';
import { Star, Check, X, ShieldCheck, Truck, CreditCard, Headphones, Award, ThumbsUp, MapPin } from 'lucide-react';
import { TESTIMONIALS, TRUST_METRICS } from '../data/techCatalog';

export const TrustProofSection: React.FC = () => {
  return (
    <section id="trust-proof" className="py-12 sm:py-16 md:py-20 bg-white border-b border-zinc-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 sm:space-y-16">
        {/* 4-Item Guarantee Strip Matching Reference Mockup */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-5 sm:p-7 bg-[#F6F8F7] rounded-3xl border border-[#E8EEEB] shadow-2xs">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-[#E6F4EE] text-[#00624A] flex items-center justify-center shrink-0 shadow-2xs">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-zinc-900 leading-tight">Original Products</h4>
              <p className="text-[11px] text-zinc-500 mt-0.5">OEM Brand Manufacturer Warranty</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-[#E6F4EE] text-[#00624A] flex items-center justify-center shrink-0 shadow-2xs">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-zinc-900 leading-tight">Express Delivery</h4>
              <p className="text-[11px] text-zinc-500 mt-0.5">Same-Day &amp; 24/48h Doorstep Handover</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-[#E6F4EE] text-[#00624A] flex items-center justify-center shrink-0 shadow-2xs">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-zinc-900 leading-tight">100% Secure Payment</h4>
              <p className="text-[11px] text-zinc-500 mt-0.5">0% No-Cost EMI &amp; Cash On Delivery</p>
            </div>
          </div>

          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-[#E6F4EE] text-[#00624A] flex items-center justify-center shrink-0 shadow-2xs">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs sm:text-sm font-bold text-zinc-900 leading-tight">Dedicated Support 7/7</h4>
              <p className="text-[11px] text-zinc-500 mt-0.5">Showroom &amp; WhatsApp Concierge</p>
            </div>
          </div>
        </div>

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#E6F4EE] text-[#00624A] rounded-full text-xs font-bold">
            <Award className="w-3.5 h-3.5" />
            <span>15+ Years Authorized Showroom Heritage</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-zinc-950 tracking-tight">
            Why 35,000+ Customers Trust Maa Gayatri Electronics
          </h2>
          <p className="text-xs sm:text-sm md:text-base text-zinc-600 leading-relaxed max-w-2xl mx-auto">
            Direct authorized brand warranties, transparent 0% No-Cost EMI financing, instant old appliance trade-in valuations, and expert same-day installation support.
          </p>
        </div>

        {/* 4 Quantitative Proof Metrics */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
          {TRUST_METRICS.map((metric, i) => (
            <div
              key={i}
              className="p-5 sm:p-6 bg-[#F8FAFA] rounded-2xl border border-zinc-200/80 text-center space-y-1 shadow-2xs"
            >
              <div className="text-2xl sm:text-4xl font-extrabold text-[#00624A] font-mono tabular-nums tracking-tight">
                {metric.value}
              </div>
              <div className="text-xs sm:text-sm font-bold text-zinc-900">{metric.label}</div>
              <p className="text-[11px] text-zinc-500">{metric.sub}</p>
            </div>
          ))}
        </div>

        {/* Comparison Table */}
        <div className="bg-[#072B23] text-white rounded-3xl p-6 sm:p-10 border border-[#0D4438] shadow-xl">
          <div className="max-w-2xl mb-8 space-y-2">
            <span className="text-xs font-mono uppercase tracking-wider text-[#34D399]">
              Honest Purchase Comparison
            </span>
            <h3 className="text-xl sm:text-3xl font-extrabold tracking-tight">
              Unorganized Local Retailers vs. Maa Gayatri Authorized Showroom
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm border-collapse min-w-[550px]">
              <thead>
                <tr className="border-b border-[#0D4438] text-zinc-300">
                  <th className="py-3 px-4 font-semibold">Service Parameter</th>
                  <th className="py-3 px-4 font-semibold text-rose-300">Unorganized Local Stores</th>
                  <th className="py-3 px-4 font-semibold text-[#34D399]">Maa Gayatri Electronics</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#0D4438] text-zinc-200">
                <tr>
                  <td className="py-3.5 px-4 font-semibold text-white">0% No-Cost EMI</td>
                  <td className="py-3.5 px-4 text-zinc-400">High hidden processing charges &amp; subvention fees</td>
                  <td className="py-3.5 px-4 text-[#34D399] font-medium flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-[#34D399] shrink-0" />
                    <span>Pure 0% No-Cost EMI on Bajaj Finserv &amp; bank cards</span>
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-semibold text-white">Warranty &amp; Invoices</td>
                  <td className="py-3.5 px-4 text-zinc-400">Handwritten estimates without OEM registration</td>
                  <td className="py-3.5 px-4 text-[#34D399] font-medium flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-[#34D399] shrink-0" />
                    <span>Original GST invoice with direct brand manufacturer warranty</span>
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-semibold text-white">Delivery &amp; Installation</td>
                  <td className="py-3.5 px-4 text-zinc-400">Customer arranges tempo and third-party mechanics</td>
                  <td className="py-3.5 px-4 text-[#34D399] font-medium flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-[#34D399] shrink-0" />
                    <span>Free insured same-day delivery with certified brand engineers</span>
                  </td>
                </tr>
                <tr>
                  <td className="py-3.5 px-4 font-semibold text-white">Old Appliance Trade-In</td>
                  <td className="py-3.5 px-4 text-zinc-400">Scrap dealer prices (₹500 – ₹1,000)</td>
                  <td className="py-3.5 px-4 text-[#34D399] font-medium flex items-center gap-1.5">
                    <Check className="w-4 h-4 text-[#34D399] shrink-0" />
                    <span>Guaranteed trade-in bonus up to ₹10,000 deducted on the spot</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Customer Testimonials */}
        <div className="space-y-6">
          <div className="text-center max-w-xl mx-auto space-y-1">
            <h3 className="text-xl sm:text-2xl font-extrabold text-zinc-950">
              Verified Customer Experiences
            </h3>
            <p className="text-xs sm:text-sm text-zinc-500">
              Real feedback from local residents who upgraded their appliances with us.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            {TESTIMONIALS.map((t) => (
              <div
                key={t.id}
                className="p-5 sm:p-6 bg-[#F8FAFA] rounded-2xl border border-zinc-200/90 shadow-2xs flex flex-col justify-between space-y-4"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      {[...Array(t.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                    <span className="text-[11px] font-medium text-zinc-400">{t.date}</span>
                  </div>

                  <p className="text-xs sm:text-sm text-zinc-700 leading-relaxed italic">
                    &ldquo;{t.comment}&rdquo;
                  </p>
                </div>

                <div className="pt-3 border-t border-zinc-200/80 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-zinc-900 block">{t.name}</span>
                    <span className="text-[11px] text-zinc-500">{t.location}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] font-bold text-[#00624A] bg-[#E6F4EE] px-2 py-0.5 rounded">
                      {t.savingsOrOutcome}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
