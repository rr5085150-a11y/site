import React, { useState } from 'react';
import { X, Calculator, CheckCircle2, ShieldCheck, CreditCard, Sparkles, ArrowRight } from 'lucide-react';
import { ProductItem } from '../types/tech';

interface EmiCalculatorModalProps {
  product?: ProductItem | null;
  isOpen: boolean;
  onClose: () => void;
  onApplyEmi: (tenureMonths: number, monthlyAmount: number, partner: string) => void;
}

export const EmiCalculatorModal: React.FC<EmiCalculatorModalProps> = ({
  product,
  isOpen,
  onClose,
  onApplyEmi
}) => {
  const [customPrice, setCustomPrice] = useState<number>(product?.price || 45000);
  const [tenure, setTenure] = useState<number>(6);
  const [selectedPartner, setSelectedPartner] = useState<string>('Bajaj Finserv EMI Card');
  const [isZeroDownPayment, setIsZeroDownPayment] = useState<boolean>(true);

  if (!isOpen) return null;

  const currentPrice = product ? product.price : customPrice;
  const downPayment = isZeroDownPayment ? 0 : Math.round(currentPrice * 0.2);
  const loanPrincipal = currentPrice - downPayment;

  // 0% No Cost EMI for 3, 6, 9 months. 12-24 months has low nominal processing
  const isNoCost = tenure <= 9;
  const annualInterestRate = isNoCost ? 0 : 0.12; // 12% standard bank EMI
  const monthlyRate = annualInterestRate / 12;

  let monthlyEmi = 0;
  if (annualInterestRate === 0) {
    monthlyEmi = Math.round(loanPrincipal / tenure);
  } else {
    monthlyEmi = Math.round(
      (loanPrincipal * monthlyRate * Math.pow(1 + monthlyRate, tenure)) /
        (Math.pow(1 + monthlyRate, tenure) - 1)
    );
  }

  const totalPayable = monthlyEmi * tenure + downPayment;
  const extraInterest = totalPayable - currentPrice;

  const financePartners = [
    { name: 'Bajaj Finserv EMI Card', tag: 'Instant 0% No-Cost EMI', instant: true },
    { name: 'HDFC Bank Credit/Debit', tag: 'Zero Down Payment', instant: true },
    { name: 'ICICI Bank Cardless EMI', tag: 'OTP Based Pre-Approved', instant: true },
    { name: 'SBI Credit Card', tag: 'Low Processing Fee', instant: true },
    { name: 'TVS Credit Consumer Loan', tag: 'Aadhaar / PAN Only', instant: false }
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-zinc-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-zinc-200/80 flex items-center justify-between bg-zinc-50">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-zinc-950 text-white rounded-xl">
              <Calculator className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600">
                Maa Gayatri Easy Finance
              </span>
              <h2 className="text-lg font-extrabold text-zinc-950">
                0% No-Cost EMI Calculator
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-400 hover:text-zinc-900 rounded-full hover:bg-zinc-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto p-6 space-y-6">
          {product ? (
            <div className="p-4 bg-zinc-50 rounded-2xl border border-zinc-200 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-semibold text-zinc-500 uppercase">Selected Model</span>
                <h4 className="text-sm font-bold text-zinc-950">{product.name}</h4>
                <span className="text-xs text-zinc-500">{product.brand} · {product.modelNumber}</span>
              </div>
              <div className="text-right">
                <span className="text-xs text-zinc-400 block">Total Price:</span>
                <span className="text-xl font-extrabold text-zinc-950 font-mono tabular-nums">
                  ₹{product.price.toLocaleString('en-IN')}
                </span>
              </div>
            </div>
          ) : (
            <div>
              <label className="text-xs font-bold text-zinc-600 block mb-1">
                Enter Purchase Amount (₹):
              </label>
              <input
                type="number"
                value={customPrice}
                onChange={(e) => setCustomPrice(Number(e.target.value))}
                className="w-full text-base font-mono font-bold p-3 bg-zinc-50 border border-zinc-300 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-zinc-950"
              />
            </div>
          )}

          {/* Down payment toggle */}
          <div className="flex items-center justify-between p-3.5 bg-zinc-50 rounded-xl border border-zinc-200 text-xs">
            <div>
              <span className="font-bold text-zinc-900 block">Zero Down Payment Scheme</span>
              <span className="text-zinc-500 text-[11px]">Take appliances home today with zero upfront down payment</span>
            </div>
            <button
              type="button"
              onClick={() => setIsZeroDownPayment(!isZeroDownPayment)}
              className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-all ${
                isZeroDownPayment
                  ? 'bg-emerald-600 text-white'
                  : 'bg-zinc-200 text-zinc-700'
              }`}
            >
              {isZeroDownPayment ? 'Active (₹0 Down)' : 'Standard (20% Down)'}
            </button>
          </div>

          {/* Tenure Selection */}
          <div>
            <span className="text-xs font-bold text-zinc-700 uppercase tracking-wider block mb-2">
              Select EMI Duration / Tenure:
            </span>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
              {[3, 6, 9, 12, 18].map((m) => {
                const isSelected = tenure === m;
                const isZeroInt = m <= 9;
                return (
                  <button
                    key={m}
                    onClick={() => setTenure(m)}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'border-zinc-950 bg-zinc-950 text-white shadow-xs'
                        : 'border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-800'
                    }`}
                  >
                    <span className="text-sm font-extrabold block font-mono">{m} Months</span>
                    <span
                      className={`text-[10px] font-bold block mt-0.5 ${
                        isSelected
                          ? isZeroInt
                            ? 'text-emerald-400'
                            : 'text-zinc-300'
                          : isZeroInt
                          ? 'text-emerald-600'
                          : 'text-zinc-400'
                      }`}
                    >
                      {isZeroInt ? '0% Interest' : 'Standard Bank'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Choose Finance Partner */}
          <div>
            <span className="text-xs font-bold text-zinc-700 uppercase tracking-wider block mb-2">
              Available EMI Partners at Maa Gayatri Store:
            </span>
            <div className="space-y-2">
              {financePartners.map((partner) => (
                <div
                  key={partner.name}
                  onClick={() => setSelectedPartner(partner.name)}
                  className={`p-3 rounded-xl border text-xs cursor-pointer flex items-center justify-between transition-all ${
                    selectedPartner === partner.name
                      ? 'border-blue-600 bg-blue-50/70 text-blue-950'
                      : 'border-zinc-200 bg-white hover:bg-zinc-50 text-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <CreditCard className="w-4 h-4 text-zinc-600" />
                    <div>
                      <span className="font-bold text-zinc-900 block">{partner.name}</span>
                      <span className="text-[10px] text-zinc-500">{partner.tag}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {partner.instant && (
                      <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                        Instant Approval
                      </span>
                    )}
                    <div
                      className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                        selectedPartner === partner.name
                          ? 'border-blue-600 bg-blue-600'
                          : 'border-zinc-300'
                      }`}
                    >
                      {selectedPartner === partner.name && (
                        <div className="w-1.5 h-1.5 rounded-full bg-white" />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Monthly EMI Output Box */}
          <div className="p-5 bg-zinc-950 text-white rounded-2xl space-y-3">
            <div className="flex justify-between items-baseline">
              <span className="text-xs font-medium text-zinc-400">Your Monthly Installment:</span>
              <div className="text-right">
                <span className="text-3xl font-extrabold text-white font-mono tabular-nums">
                  ₹{monthlyEmi.toLocaleString('en-IN')}
                </span>
                <span className="text-xs text-zinc-400 block">/ month for {tenure} months</span>
              </div>
            </div>

            <div className="pt-3 border-t border-zinc-800 text-xs space-y-1.5">
              <div className="flex justify-between text-zinc-400">
                <span>Down Payment Today:</span>
                <span className="text-white font-mono font-bold">
                  ₹{downPayment.toLocaleString('en-IN')}
                </span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Interest Charge (Extra):</span>
                <span className="text-emerald-400 font-bold font-mono">
                  {isNoCost ? '₹0 (100% No-Cost EMI)' : `₹${extraInterest.toLocaleString('en-IN')}`}
                </span>
              </div>
              <div className="flex justify-between text-zinc-400">
                <span>Documents Needed:</span>
                <span className="text-zinc-200">Only Aadhaar Card &amp; PAN Card</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Action */}
        <div className="p-6 bg-zinc-50 border-t border-zinc-200/80 flex items-center justify-between gap-3">
          <div className="text-xs text-zinc-500 hidden sm:block">
            <span>Instant in-store &amp; doorstep EMI verification</span>
          </div>
          <button
            onClick={() => {
              onApplyEmi(tenure, monthlyEmi, selectedPartner);
              onClose();
            }}
            className="w-full sm:w-auto px-6 py-3 bg-zinc-950 hover:bg-zinc-800 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2"
          >
            <span>Proceed with ₹{monthlyEmi.toLocaleString('en-IN')}/mo EMI</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
