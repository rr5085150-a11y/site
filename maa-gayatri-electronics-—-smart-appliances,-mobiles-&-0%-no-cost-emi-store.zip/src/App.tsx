import React, { useState } from 'react';
import {
  Scale,
  Search,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  RefreshCw,
  Sparkles,
  SlidersHorizontal
} from 'lucide-react';
import { ProductItem, ServiceOption, TechCategory, CartBookingItem } from './types/tech';
import { TECH_CATALOG } from './data/techCatalog';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { BrowseByCategory } from './components/BrowseByCategory';
import { SpecialPromoBanner } from './components/SpecialPromoBanner';
import { ProductCard } from './components/ProductCard';
import { ComparisonModal } from './components/ComparisonModal';
import { ComparisonDock } from './components/ComparisonDock';
import { DiagnosticEstimator } from './components/DiagnosticEstimator';
import { BatteryFocusSection } from './components/BatteryFocusSection';
import { TrustProofSection } from './components/TrustProofSection';
import { CartBookingDrawer } from './components/CartBookingDrawer';
import { ProductDetailModal } from './components/ProductDetailModal';
import { EmiCalculatorModal } from './components/EmiCalculatorModal';
import { OldApplianceExchangeModal } from './components/OldApplianceExchangeModal';
import { ImageManagerModal } from './components/ImageManagerModal';
import { WhatsAppFloat } from './components/WhatsAppFloat';
import { Footer } from './components/Footer';

export default function App() {
  const [catalog, setCatalog] = useState<ProductItem[]>(TECH_CATALOG);
  const [selectedCategory, setSelectedCategory] = useState<TechCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [comparedProducts, setComparedProducts] = useState<ProductItem[]>([]);
  const [isComparisonOpen, setIsComparisonOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartBookingItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [detailProduct, setDetailProduct] = useState<ProductItem | null>(null);

  // EMI, Exchange & Image state
  const [isEmiModalOpen, setIsEmiModalOpen] = useState(false);
  const [selectedEmiProduct, setSelectedEmiProduct] = useState<ProductItem | null>(null);
  const [isExchangeModalOpen, setIsExchangeModalOpen] = useState(false);
  const [exchangeDiscount, setExchangeDiscount] = useState<number>(0);
  const [exchangeDeviceName, setExchangeDeviceName] = useState<string>('');
  const [imageTargetProduct, setImageTargetProduct] = useState<ProductItem | null>(null);

  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification((curr) => (curr === msg ? null : curr));
    }, 3200);
  };

  const handleSaveCustomImage = (productId: string, newUrl: string) => {
    setCatalog((prev) =>
      prev.map((item) => (item.id === productId ? { ...item, imageUrl: newUrl } : item))
    );
    showNotification('Product photo updated successfully!');
  };

  // Compare toggles
  const handleToggleCompare = (product: ProductItem) => {
    const exists = comparedProducts.some((p) => p.id === product.id);
    if (exists) {
      setComparedProducts(comparedProducts.filter((p) => p.id !== product.id));
      showNotification(`Removed "${product.name}" from comparison`);
    } else {
      if (comparedProducts.length >= 3) {
        showNotification('Maximum 3 items can be compared side-by-side');
        return;
      }
      setComparedProducts([...comparedProducts, product]);
      showNotification(`Added "${product.name}" to comparison`);
    }
  };

  const handleRemoveCompare = (id: string) => {
    setComparedProducts(comparedProducts.filter((p) => p.id !== id));
  };

  const handleClearCompare = () => {
    setComparedProducts([]);
  };

  // Cart & Booking actions
  const handleAddToCart = (product: ProductItem, paymentPlan: 'full' | 'emi' = 'full') => {
    const existingIndex = cartItems.findIndex(
      (item) => item.product.id === product.id && item.type === 'purchase'
    );
    if (existingIndex > -1) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += 1;
      updated[existingIndex].paymentPlan = paymentPlan;
      setCartItems(updated);
    } else {
      setCartItems([
        ...cartItems,
        {
          id: 'cart-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
          product,
          type: 'purchase',
          quantity: 1,
          paymentPlan
        }
      ]);
    }
    showNotification(
      paymentPlan === 'emi'
        ? `Added ${product.name} with 0% No-Cost EMI (₹${product.emiPerMonth}/mo)`
        : `Added ${product.name} to Cart`
    );
    setIsCartOpen(true);
  };

  const handleTogglePaymentPlan = (id: string, plan: 'full' | 'emi') => {
    setCartItems(
      cartItems.map((item) => {
        if (item.id === id) {
          return { ...item, paymentPlan: plan };
        }
        return item;
      })
    );
  };

  const handleBookService = (product: ProductItem, service: ServiceOption) => {
    setCartItems([
      ...cartItems,
      {
        id: 'book-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
        product,
        type: 'repair',
        selectedService: service,
        quantity: 1,
        paymentPlan: 'full'
      }
    ]);
    showNotification(`Booked service: ${service.name}`);
    setIsCartOpen(true);
  };

  const handleBookDirectDiagnostic = (
    categoryLabel: string,
    issueName: string,
    estimatedPrice: string
  ) => {
    const matchingProduct =
      TECH_CATALOG.find((p) => categoryLabel.toLowerCase().includes(p.category)) ||
      TECH_CATALOG[0];

    const numericPrice = parseInt(
      estimatedPrice.replace(/[^0-9]/g, '').slice(0, 4) || '1499',
      10
    );

    const directService: ServiceOption = {
      id: 'dir-' + Date.now(),
      name: `${categoryLabel} — ${issueName}`,
      description: 'Doorstep diagnosis, calibration, and OEM repair with official warranty.',
      price: numericPrice,
      durationMinutes: 45,
      warrantyDays: 365
    };

    handleBookService(matchingProduct, directService);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems(
      cartItems
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartBookingItem[]
    );
  };

  const handleRemoveCartItem = (id: string) => {
    setCartItems(cartItems.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // EMI modal trigger
  const handleOpenEmiModal = (product?: ProductItem) => {
    setSelectedEmiProduct(product || null);
    setIsEmiModalOpen(true);
  };

  const handleApplyEmiPlan = (tenureMonths: number, monthlyAmount: number, partner: string) => {
    if (selectedEmiProduct) {
      handleAddToCart(selectedEmiProduct, 'emi');
      showNotification(`Selected ${partner}: ₹${monthlyAmount}/mo for ${tenureMonths} Months`);
    } else {
      showNotification(`Pre-Approved for 0% EMI with ${partner}`);
      setIsCartOpen(true);
    }
  };

  // Exchange valuation trigger
  const handleApplyExchange = (deviceName: string, discount: number) => {
    setExchangeDeviceName(deviceName);
    setExchangeDiscount(discount);
    showNotification(`₹${discount.toLocaleString('en-IN')} Exchange Bonus Applied!`);
    setIsCartOpen(true);
  };

  // Filtering
  const filteredProducts = catalog.filter((item) => {
    const matchesCategory =
      selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch =
      searchQuery.trim() === '' ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.tagline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const batteryProducts = catalog.filter(
    (p) => p.category === 'mobiles' || p.iconType === 'battery'
  );

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCategorySelect = (cat: TechCategory) => {
    setSelectedCategory(cat);
    scrollToSection('catalog');
  };

  return (
    <div className="min-h-screen bg-white text-zinc-950 flex flex-col font-sans selection:bg-[#00624A] selection:text-white">
      {/* Top Promotional Ribbon */}
      <div className="h-9 bg-[#072B23] text-white text-[11px] sm:text-xs font-semibold px-4 flex items-center justify-between border-b border-[#0C3D32]">
        <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[#34D399] font-extrabold">MAA GAYATRI ELECTRONICS:</span>
            <span>0% No-Cost EMI on Bajaj Finserv &amp; Major Bank Cards · Trade-In Bonus Up to ₹10,000 Off</span>
          </div>
          <span className="hidden sm:inline font-mono text-zinc-300">
            Showroom Helpline: +91 98260 54321
          </span>
        </div>
      </div>

      {/* Top Bar Navigation matching reference mockup */}
      <Navbar
        cartItems={cartItems}
        comparedCount={comparedProducts.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenCompare={() => setIsComparisonOpen(true)}
        onOpenEmiModal={() => handleOpenEmiModal()}
        onOpenExchangeModal={() => setIsExchangeModalOpen(true)}
        onScrollToSection={scrollToSection}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {/* Hero Showcase matching reference mockup with 3D podium and carousel */}
      <Hero
        selectedCategory={selectedCategory}
        onSelectCategory={handleCategorySelect}
        onOpenCompare={() => setIsComparisonOpen(true)}
        onOpenEmiModal={() => handleOpenEmiModal()}
        onOpenExchangeModal={() => setIsExchangeModalOpen(true)}
        onScrollToCatalog={() => scrollToSection('catalog')}
      />

      {/* Browse by Category Section matching "Parcourir par catégorie" in mockup */}
      <div id="categories">
        <BrowseByCategory
          selectedCategory={selectedCategory}
          onSelectCategory={handleCategorySelect}
          onViewAll={() => {
            setSelectedCategory('all');
            scrollToSection('catalog');
          }}
        />
      </div>

      {/* Best Sellers & Product Catalog Section matching reference */}
      <section id="catalog" className="py-10 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Catalog Header with Search & Filter Controls matching "Les meilleures ventes" */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8 pb-6 border-b border-zinc-200/80">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="w-6 h-0.5 bg-[#00624A]" />
              <span className="text-[11px] sm:text-xs font-bold uppercase tracking-wider text-[#00624A]">
                Featured Products
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-zinc-950 tracking-tight">
              Best Sellers &amp; Showroom Collection
            </h2>
            <p className="text-xs sm:text-sm text-zinc-500 mt-1">
              All models available with instant 0% No-Cost EMI, full payment, and same-day delivery.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
            {/* Search Input */}
            <div className="relative flex-1 sm:w-72">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search smartphone, AC, TV, laptop..."
                className="w-full pl-9 pr-4 py-2.5 bg-[#F6F8F7] focus:bg-white border border-[#E2E8E4] focus:border-[#00624A] rounded-xl text-xs sm:text-sm text-zinc-900 focus:outline-hidden transition-all placeholder:text-zinc-400"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-zinc-400 hover:text-zinc-900 font-bold"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Compare Trigger if items selected */}
            {comparedProducts.length > 0 && (
              <button
                onClick={() => setIsComparisonOpen(true)}
                className="px-4 py-2.5 bg-[#00624A] text-white rounded-xl text-xs font-semibold hover:bg-[#004D3A] transition-colors flex items-center justify-center gap-1.5 shrink-0 shadow-sm"
              >
                <Scale className="w-3.5 h-3.5" />
                <span>Compare ({comparedProducts.length})</span>
              </button>
            )}
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-6">
          {(
            [
              { id: 'all', label: 'All Products' },
              { id: 'mobiles', label: 'Smartphones & Tech' },
              { id: 'ac', label: 'Inverter ACs' },
              { id: 'tv', label: 'Smart 4K OLED TVs' },
              { id: 'fridge', label: 'Refrigerators' },
              { id: 'washing', label: 'Washing Machines' },
              { id: 'inverter', label: 'Inverters & Power' },
              { id: 'kitchen', label: 'Kitchen & Microwave' }
            ] as const
          ).map((tab) => {
            const isActive = selectedCategory === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setSelectedCategory(tab.id)}
                className={`py-2 px-4 rounded-full text-xs font-bold transition-all whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-[#00624A] text-white shadow-xs'
                    : 'bg-[#F6F8F7] hover:bg-[#EEF4F1] text-zinc-700 border border-[#E8EEEB]'
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Product Cards Grid: 4 columns on large displays matching mockup */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-16 bg-[#F8FAFA] rounded-3xl border border-zinc-200 p-8 space-y-3">
            <AlertCircle className="w-10 h-10 text-zinc-400 mx-auto" />
            <h3 className="text-base font-bold text-zinc-800">No electronics match your search</h3>
            <p className="text-xs text-zinc-500 max-w-sm mx-auto">
              Try searching for "iPhone", "MacBook", "Daikin", "Sony", "LG", "Fridge", or "Inverter".
            </p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="mt-2 px-5 py-2.5 bg-[#00624A] text-white rounded-xl text-xs font-bold shadow-sm"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6">
            {filteredProducts.map((product) => {
              const isCompared = comparedProducts.some((p) => p.id === product.id);
              return (
                <ProductCard
                  key={product.id}
                  product={product}
                  isCompared={isCompared}
                  onToggleCompare={handleToggleCompare}
                  onAddToCart={handleAddToCart}
                  onBookService={handleBookService}
                  onViewDetails={setDetailProduct}
                  onOpenEmiCalculator={handleOpenEmiModal}
                  onOpenExchangeModal={() => setIsExchangeModalOpen(true)}
                  onOpenChangeImage={setImageTargetProduct}
                />
              );
            })}
          </div>
        )}
      </section>

      {/* Special Promo Feature Banner matching "Offre spéciale" in mockup */}
      <SpecialPromoBanner
        onExploreOffers={() => scrollToSection('catalog')}
        onOpenEmiModal={() => handleOpenEmiModal()}
      />

      {/* Interactive Repair Diagnostic & Cost Estimator */}
      <div id="diagnostic">
        <DiagnosticEstimator onBookDirectService={handleBookDirectDiagnostic} />
      </div>

      {/* Dedicated Battery & Mobile Tech Section */}
      <BatteryFocusSection
        batteryProducts={batteryProducts}
        onBookBattery={(p) => {
          if (p.services[0]) {
            handleBookService(p, p.services[0]);
          } else {
            handleAddToCart(p);
          }
        }}
        onViewSpecs={setDetailProduct}
      />

      {/* Trust & Proof Section with 4 Guarantee Pillars */}
      <TrustProofSection />

      {/* Footer matching dark emerald green mockup */}
      <Footer
        onScrollToSection={scrollToSection}
        onOpenEmiModal={() => handleOpenEmiModal()}
        onOpenExchangeModal={() => setIsExchangeModalOpen(true)}
      />

      {/* Floating Bottom Comparison Dock (active when items selected) */}
      <ComparisonDock
        comparedProducts={comparedProducts}
        onRemove={handleRemoveCompare}
        onClear={handleClearCompare}
        onOpenModal={() => setIsComparisonOpen(true)}
      />

      {/* Side-by-Side Product Comparison Modal */}
      <ComparisonModal
        products={comparedProducts}
        isOpen={isComparisonOpen}
        onClose={() => setIsComparisonOpen(false)}
        onRemoveProduct={handleRemoveCompare}
        onAddToCart={handleAddToCart}
      />

      {/* Deep-Dive Product Detail Modal */}
      <ProductDetailModal
        product={detailProduct}
        isOpen={!!detailProduct}
        onClose={() => setDetailProduct(null)}
        onAddToCart={handleAddToCart}
        onBookService={handleBookService}
      />

      {/* Interactive 0% No Cost EMI Calculator Modal */}
      <EmiCalculatorModal
        product={selectedEmiProduct}
        isOpen={isEmiModalOpen}
        onClose={() => {
          setIsEmiModalOpen(false);
          setSelectedEmiProduct(null);
        }}
        onApplyEmi={handleApplyEmiPlan}
      />

      {/* Old Appliance Exchange Valuation Modal */}
      <OldApplianceExchangeModal
        isOpen={isExchangeModalOpen}
        onClose={() => setIsExchangeModalOpen(false)}
        onApplyExchange={handleApplyExchange}
      />

      {/* Cart & Doorstep Appointment Drawer */}
      <CartBookingDrawer
        isOpen={isCartOpen}
        cartItems={cartItems}
        exchangeDiscount={exchangeDiscount}
        exchangeDeviceName={exchangeDeviceName}
        onClose={() => setIsCartOpen(false)}
        onUpdateQuantity={handleUpdateQuantity}
        onTogglePaymentPlan={handleTogglePaymentPlan}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        onOpenExchangeModal={() => setIsExchangeModalOpen(true)}
      />

      {/* Interactive Photo Customizer Modal */}
      <ImageManagerModal
        product={imageTargetProduct}
        isOpen={!!imageTargetProduct}
        onClose={() => setImageTargetProduct(null)}
        onSaveImageUrl={handleSaveCustomImage}
      />

      {/* Floating 24x7 WhatsApp Showroom Concierge */}
      <WhatsAppFloat />

      {/* Floating Action Toast Notification */}
      {notification && (
        <div className="fixed top-20 right-5 z-50 bg-[#072B23] text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-xl border border-[#0C3D32] flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="w-4 h-4 text-[#34D399] shrink-0" />
          <span>{notification}</span>
        </div>
      )}
    </div>
  );
}
