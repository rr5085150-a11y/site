export type TechCategory =
  | 'all'
  | 'ac'
  | 'tv'
  | 'fridge'
  | 'washing'
  | 'mobiles'
  | 'inverter'
  | 'kitchen';

export interface TechSpec {
  label: string;
  value: string;
}

export interface ServiceOption {
  id: string;
  name: string;
  description: string;
  price: number;
  durationMinutes: number;
  warrantyDays: number;
}

export interface ProductItem {
  id: string;
  name: string;
  brand: string;
  category: 'ac' | 'tv' | 'fridge' | 'washing' | 'mobiles' | 'inverter' | 'kitchen';
  tagline: string;
  price: number;
  originalPrice: number;
  rating: number;
  reviewsCount: number;
  inStock: boolean;
  warrantyYears: number;
  deliveryDays: number;
  highlights: string[];
  specs: Record<string, string>;
  services: ServiceOption[];
  modelNumber: string;
  energyRating?: string;
  iconType: 'ac' | 'tv' | 'fridge' | 'washing' | 'mobiles' | 'inverter' | 'kitchen' | 'battery';
  imageUrl?: string;
  // EMI & Finance Parameters
  emiPerMonth: number;
  emiMonths: number[];
  zeroDownPayment: boolean;
  exchangeBonus?: number;
}

export interface CartBookingItem {
  id: string;
  product: ProductItem;
  type: 'purchase' | 'repair';
  selectedService?: ServiceOption;
  quantity: number;
  paymentPlan: 'full' | 'emi';
  emiMonthsSelected?: number;
  exchangeDiscountApplied?: number;
}

export interface CustomerBookingForm {
  fullName: string;
  phoneNumber: string;
  streetAddress: string;
  city: string;
  postalCode: string;
  preferredDate: string;
  preferredSlot: string;
  paymentMethod: 'cod' | 'upi' | 'emi_bajaj' | 'emi_credit_card' | 'store_pickup';
  exchangeOldItem?: string;
  serviceNotes: string;
}

export interface TestimonialItem {
  id: string;
  name: string;
  location: string;
  deviceWorkedOn: string;
  type: 'Appliance Purchase with EMI' | 'Exchange Deal' | 'Repair & Installation';
  rating: number;
  verified: boolean;
  comment: string;
  date: string;
  savingsOrOutcome: string;
}
