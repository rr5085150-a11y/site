import { ProductItem, TestimonialItem } from '../types/tech';

export const TECH_CATALOG: ProductItem[] = [
  // ==================== 1. AIR CONDITIONERS ====================
  {
    id: 'ac-daikin-inverter-15',
    name: 'Daikin 1.5 Ton 5-Star Triple Display Inverter AC',
    brand: 'Daikin Japan',
    category: 'ac',
    tagline: 'Copper Condenser with PM 2.5 Filter, Dew Clean Technology, and 5-Star Energy Efficiency.',
    price: 44990,
    originalPrice: 59990,
    rating: 4.9,
    reviewsCount: 680,
    inStock: true,
    warrantyYears: 5,
    deliveryDays: 1,
    energyRating: '5 Star BEE (ISEER 5.2)',
    modelNumber: 'FTKM50U',
    iconType: 'ac',
    imageUrl: 'https://images.unsplash.com/photo-1614633833026-06204c6a6f69?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 3749,
    emiMonths: [3, 6, 9, 12, 18, 24],
    zeroDownPayment: true,
    exchangeBonus: 6500,
    highlights: [
      '1.5 Ton capacity — rapid cooling for spaces up to 180 sq.ft in 5 minutes',
      'Triple Display shows room temperature, target temperature, and error codes',
      'Dew Clean technology self-cleans indoor heat exchanger using condensation',
      '10-Year compressor warranty with complimentary installation support'
    ],
    specs: {
      'Cooling Capacity': '1.5 Ton (5280 W)',
      'Energy Efficiency': '5 Star BEE / ISEER 5.2',
      'Compressor Type': 'Swing Inverter Compressor (Zero Friction)',
      'Condenser Coil': '100% Grooved Copper with Anti-Corrosion Treatment',
      'Noise Level': 'Ultra-Quiet 29 dB(A)',
      'Refrigerant': 'Eco-Friendly R32',
      'Smart Connectivity': 'Wi-Fi Ready & Mobile App Support',
      'Power Consumption': '785 kWh / Year',
      'Air Filtration': 'PM 2.5 Filter + Anti-Bacterial Enzyme Filter'
    },
    services: [
      {
        id: 'srv-ac-deep-jet',
        name: 'Master Jet Pump Deep Coil Clean & Sanitization',
        description: 'Complete high-pressure cleaning of indoor and outdoor coils with anti-bacterial foam.',
        price: 999,
        durationMinutes: 45,
        warrantyDays: 60
      },
      {
        id: 'srv-ac-gas-charge',
        name: 'Precision Gas Leak Repair & R32 Top-Up',
        description: 'Nitrogen pressure leak detection, copper brazing fix, and factory gas filling.',
        price: 2450,
        durationMinutes: 60,
        warrantyDays: 180
      }
    ]
  },
  {
    id: 'ac-lg-dual-inverter-15',
    name: 'LG 1.5 Ton AI Dual Inverter Split AC',
    brand: 'LG Electronics',
    category: 'ac',
    tagline: '6-in-1 Convertible AI Cooling with Ocean Black Protection and 4-Way Air Swing.',
    price: 42990,
    originalPrice: 57990,
    rating: 4.8,
    reviewsCount: 540,
    inStock: true,
    warrantyYears: 5,
    deliveryDays: 1,
    energyRating: '5 Star BEE (ISEER 5.0)',
    modelNumber: 'TS-Q19YNZE',
    iconType: 'ac',
    imageUrl: 'https://images.unsplash.com/photo-1585338107529-13afc5f02586?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 3582,
    emiMonths: [3, 6, 9, 12, 18],
    zeroDownPayment: true,
    exchangeBonus: 6000,
    highlights: [
      'Dual Rotary Inverter with AI Convertible 6-in-1 modes',
      'Engineered to cool even in extreme ambient temperatures up to 52°C',
      'Ocean Black Fin anti-corrosion coating prevents rust and weathering',
      'Low gas detection alert via LG ThinQ mobile app'
    ],
    specs: {
      'Cooling Capacity': '1.5 Ton (5000 W)',
      'Energy Efficiency': '5 Star BEE / ISEER 5.0',
      'Compressor Type': 'AI Dual Inverter with Variable Speed Dual Rotary',
      'Condenser Coil': '100% Pure Copper with Ocean Black Coating',
      'Noise Level': 'Silent 26 dB(A)',
      'Refrigerant': 'R32 High Efficiency',
      'Smart Connectivity': 'LG ThinQ Wi-Fi, Alexa & Google Assistant',
      'Power Consumption': '818 kWh / Year',
      'Air Filtration': 'HD Filter with Anti-Virus Coating'
    },
    services: [
      {
        id: 'srv-lg-ac-service',
        name: 'LG Authorized Deep Preventive Servicing',
        description: 'Filter wash, blower de-linting, drain clearing, and electrical testing.',
        price: 899,
        durationMinutes: 40,
        warrantyDays: 90
      }
    ]
  },

  // ==================== 2. SMART TELEVISIONS ====================
  {
    id: 'tv-sony-bravia-65',
    name: 'Sony Bravia XR 65" 4K Cinema Google TV',
    brand: 'Sony India',
    category: 'tv',
    tagline: 'Cognitive Processor XR, Acoustic Multi-Audio, Dolby Vision & 120Hz Gaming Turbo.',
    price: 114990,
    originalPrice: 154990,
    rating: 4.9,
    reviewsCount: 420,
    inStock: true,
    warrantyYears: 3,
    deliveryDays: 1,
    energyRating: 'A+ High Efficiency 4K Panel',
    modelNumber: 'XR-65X90L',
    iconType: 'tv',
    imageUrl: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 4791,
    emiMonths: [3, 6, 9, 12, 18, 24],
    zeroDownPayment: true,
    exchangeBonus: 8000,
    highlights: [
      '65-Inch Full Array LED with Cognitive Processor XR for lifelike visual depth',
      'HDMI 2.1, 4K/120Hz, VRR, ALLM optimized for PlayStation 5 consoles',
      'Acoustic Multi-Audio speakers perfectly synchronized to on-screen action',
      'Google TV with hands-free far-field voice control built into the frame'
    ],
    specs: {
      'Screen Size': '65 Inch (164 cm diagonal)',
      'Display Panel': 'Full Array LED 4K (3840 x 2160) with XR Triluminos Pro',
      'Refresh Rate': '120Hz Native with Variable Refresh Rate (VRR)',
      'HDR Support': 'Dolby Vision, HDR10, HLG, IMAX Enhanced',
      'Audio Output': '30W RMS Acoustic Multi-Audio with Sound Positioning Tweeters',
      'Processor': 'Sony Cognitive Processor XR with AI Upscaling',
      'Ports': '4x HDMI (2x HDMI 2.1 eARC), 2x USB, Optical, Wi-Fi 6',
      'Operating System': 'Google TV with Apple AirPlay 2 & HomeKit Support',
      'Bezel Thickness': 'Seamless Edge Slim Aluminum Bezel'
    },
    services: [
      {
        id: 'srv-sony-wallmount',
        name: 'Professional Swivel Wall Mount & Cable Concealment',
        description: 'Heavy duty cold-rolled steel bracket, stud testing, and concealed in-wall cabling.',
        price: 799,
        durationMinutes: 45,
        warrantyDays: 365
      }
    ]
  },
  {
    id: 'tv-samsung-crystal-55',
    name: 'Samsung Crystal 4K Dynamic 55" Smart TV',
    brand: 'Samsung',
    category: 'tv',
    tagline: 'Dynamic Crystal Color with AirSlim Design, Object Tracking Sound Lite and SolarCell Remote.',
    price: 43990,
    originalPrice: 62900,
    rating: 4.8,
    reviewsCount: 610,
    inStock: true,
    warrantyYears: 3,
    deliveryDays: 1,
    energyRating: '5 Star Energy Compliant',
    modelNumber: 'UA55CUE70',
    iconType: 'tv',
    imageUrl: 'https://images.unsplash.com/photo-1593784991095-a205069470b6?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 3665,
    emiMonths: [3, 6, 9, 12],
    zeroDownPayment: true,
    exchangeBonus: 5000,
    highlights: [
      '55-Inch 4K UHD with 1 Billion True-to-Life Colors',
      'AirSlim profile under 25mm thickness mounts almost flush against your wall',
      'SolarCell Remote recharges from ambient indoor lighting — zero battery waste',
      'Samsung Knox Security protects your personal streaming accounts and home network'
    ],
    specs: {
      'Screen Size': '55 Inch (138 cm diagonal)',
      'Display Panel': 'Crystal 4K Ultra HD (3840 x 2160)',
      'Refresh Rate': '60Hz with Motion Xcelerator',
      'HDR Support': 'HDR10+, HLG with Mega Contrast',
      'Audio Output': '20W RMS (Q-Symphony soundbar sync ready)',
      'Processor': 'Crystal Processor 4K with AI Upscaling',
      'Ports': '3x HDMI, 1x USB, eARC, Optical, Bluetooth 5.2',
      'Operating System': 'Samsung Tizen OS with all major streaming apps',
      'Design': '3-Side Bezel-Less AirSlim Look'
    },
    services: [
      {
        id: 'srv-tv-backlight-repair',
        name: 'LED Backlight Strip Matrix Replacement',
        description: 'Replaces dim or flickering backlight strips with genuine factory arrays.',
        price: 2400,
        durationMinutes: 60,
        warrantyDays: 180
      }
    ]
  },

  // ==================== 3. REFRIGERATORS ====================
  {
    id: 'fridge-samsung-bespoke-580',
    name: 'Samsung Bespoke 580L Multi-Door French Refrigerator',
    brand: 'Samsung Bespoke',
    category: 'fridge',
    tagline: 'Triple Cooling System with Convertible FlexZone, Beverage Center & 20-Yr Compressor Warranty.',
    price: 86990,
    originalPrice: 119990,
    rating: 4.9,
    reviewsCount: 310,
    inStock: true,
    warrantyYears: 5,
    deliveryDays: 1,
    energyRating: '5 Star Inverter Compressor',
    modelNumber: 'RF57A5032',
    iconType: 'fridge',
    imageUrl: 'https://images.unsplash.com/photo-1571175443880-49e1d25b2bc5?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 3624,
    emiMonths: [3, 6, 9, 12, 18, 24],
    zeroDownPayment: true,
    exchangeBonus: 7500,
    highlights: [
      '580 Liters gross capacity designed for large modern households',
      'Twin Cooling Plus independent cooling circuits keep produce fresh up to 15 days',
      'AutoFill water pitcher with fruit infuser integrated into the inner door',
      '20-Year digital inverter compressor warranty backed directly by Samsung'
    ],
    specs: {
      'Total Capacity': '580 Litres (Fridge: 381L | Freezer: 199L)',
      'Configuration': 'French Door Multi-Door Quad Design',
      'Cooling Technology': 'Triple Cooling System with Metal Cooling Armor',
      'Compressor Type': 'Digital Inverter with 7-Speed Auto Modulation',
      'Defrosting Type': 'Frost-Free Auto Clean Defrost',
      'Noise Level': 'Ultra-quiet 35 dB operation',
      'Finish / Material': 'Matte Glass & Stainless Steel Anti-Fingerprint',
      'Smart Features': 'SmartThings Wi-Fi with AI Energy Optimization',
      'Energy Consumption': '265 kWh / Year'
    },
    services: [
      {
        id: 'srv-fridge-compressor',
        name: 'Inverter Compressor Swap & Gas Recharge',
        description: 'OEM compressor installation, filter drier change, high vacuuming, and factory charge.',
        price: 4800,
        durationMinutes: 120,
        warrantyDays: 365
      }
    ]
  },
  {
    id: 'fridge-whirlpool-340',
    name: 'Whirlpool Intellifresh 340L Double Door Refrigerator',
    brand: 'Whirlpool',
    category: 'fridge',
    tagline: 'Adaptive Intelligence Technology, Microblock Fruit Crisper & 10-in-1 Convertible Modes.',
    price: 35990,
    originalPrice: 46990,
    rating: 4.8,
    reviewsCount: 480,
    inStock: true,
    warrantyYears: 5,
    deliveryDays: 1,
    energyRating: '3 Star BEE (Energy Saver)',
    modelNumber: 'IF-PRO-340L',
    iconType: 'fridge',
    imageUrl: 'https://images.unsplash.com/photo-1584992236310-6edddc08acff?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 2999,
    emiMonths: [3, 6, 9, 12],
    zeroDownPayment: true,
    exchangeBonus: 4500,
    highlights: [
      '340 Liters convertible refrigerator optimal for families of 3-5 members',
      'Intellisense Inverter Compressor with whisper-silent operation',
      'Microblock technology prevents up to 99% bacterial growth on fruits and vegetables',
      'Automatically synchronizes with home inverter power during outages'
    ],
    specs: {
      'Total Capacity': '340 Litres (Fridge: 244L | Freezer: 96L)',
      'Configuration': 'Double Door Top Mount Freezer',
      'Cooling Technology': '3D Airflow with FreshFlow Air Tower',
      'Compressor Type': 'Intellisense Inverter Low-Vibration Compressor',
      'Defrosting Type': 'Auto Frost-Free',
      'Noise Level': 'Quiet 36 dB',
      'Finish / Material': 'Omega Steel Brushed Metallic',
      'Smart Features': 'Auto-Connect to Home Inverter',
      'Energy Consumption': '207 kWh / Year'
    },
    services: [
      {
        id: 'srv-fridge-maintenance',
        name: 'Annual Condenser Clean & Thermostat Calibration',
        description: 'Restores rapid freezing and prevents high electricity bills.',
        price: 899,
        durationMinutes: 45,
        warrantyDays: 90
      }
    ]
  },

  // ==================== 4. WASHING MACHINES ====================
  {
    id: 'wash-lg-ai-front-8',
    name: 'LG 8.0 Kg AI Direct Drive Front Load Washing Machine',
    brand: 'LG Electronics',
    category: 'washing',
    tagline: 'AI DD Fabric Sensing with Steam Allergiene Wash, TurboWash 59 & Wi-Fi ThinQ.',
    price: 36990,
    originalPrice: 48990,
    rating: 4.9,
    reviewsCount: 520,
    inStock: true,
    warrantyYears: 5,
    deliveryDays: 1,
    energyRating: '5 Star BEE Highest Thrift',
    modelNumber: 'FHM1408BDW',
    iconType: 'washing',
    imageUrl: 'https://images.unsplash.com/photo-1610557892470-55d9e80c0bce?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 3082,
    emiMonths: [3, 6, 9, 12, 18],
    zeroDownPayment: true,
    exchangeBonus: 4500,
    highlights: [
      '8 Kg capacity perfect for heavy daily loads, bed linens, and delicate cottons',
      'AI Direct Drive analyzes fabric weight and softness to select optimal 6-motion cycles',
      'Steam Allergiene cycle eliminates up to 99.9% of dust mites and allergens',
      '10-Year warranty on Inverter Direct Drive motor'
    ],
    specs: {
      'Washing Capacity': '8.0 Kg Front Load',
      'Spin Speed': '1400 RPM for 80% Moisture Extraction',
      'Motor Type': 'Inverter Direct Drive (Belt-Less, Zero Vibration)',
      'Wash Programs': '14 Dedicated Cycles (Cotton, Steam, TurboWash, Delicates)',
      'Heater': 'Built-in Inverter Water Heater up to 95°C',
      'Smart Features': 'LG ThinQ Wi-Fi Remote Start & Cycle Download',
      'Tub Material': 'Full Stainless Steel Embossed Drum',
      'Energy Rating': '5 Star BEE with Eco Inverter Motor'
    },
    services: [
      {
        id: 'srv-wash-drum-clean',
        name: 'Deep Descaling & High-Temp Tub Sterilization',
        description: 'Chemical lime descaling, pump filter extraction, and drain pipe sanitization.',
        price: 799,
        durationMinutes: 45,
        warrantyDays: 90
      }
    ]
  },
  {
    id: 'wash-bosch-series-75',
    name: 'Bosch 7.5 Kg 5-Star Fully Automatic Top Load',
    brand: 'Bosch Home',
    category: 'washing',
    tagline: 'VarioInverter Motor with PowerWave Wash System & Soft Close Toughened Glass Lid.',
    price: 21990,
    originalPrice: 28990,
    rating: 4.8,
    reviewsCount: 390,
    inStock: true,
    warrantyYears: 5,
    deliveryDays: 1,
    energyRating: '5 Star BEE Efficiency',
    modelNumber: 'WOE751D0IN',
    iconType: 'washing',
    imageUrl: 'https://images.unsplash.com/photo-1582735689369-4fe89db7114c?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 1832,
    emiMonths: [3, 6, 9, 12],
    zeroDownPayment: true,
    exchangeBonus: 3500,
    highlights: [
      '7.5 Kg compact footprint top load engineered for everyday household washing',
      'PowerWave pulsator system creates dynamic water flow without tangling fabric',
      'One-touch Smart Suggest program selects cycle automatically',
      'Soft-closing tempered glass lid prevents accidental slamming'
    ],
    specs: {
      'Washing Capacity': '7.5 Kg Top Load',
      'Spin Speed': '680 RPM',
      'Motor Type': 'VarioInverter Quiet Motor',
      'Wash Programs': '8 Pre-Set Customized Wash Programs',
      'Tub Material': 'Stainless Steel VarioDrum',
      'Energy Rating': '5 Star BEE with Low Water Consumption'
    },
    services: [
      {
        id: 'srv-bosch-wash-service',
        name: 'Pulsator Inspection & Motor Belt Alignment',
        description: 'Inspection of suspension springs, water inlet valve, and spin calibration.',
        price: 699,
        durationMinutes: 40,
        warrantyDays: 60
      }
    ]
  },

  // ==================== 5. SMARTPHONES & BATTERIES ====================
  {
    id: 'mob-iphone-15-pro',
    name: 'Apple iPhone 15 Pro (256 GB) — Natural Titanium',
    brand: 'Apple Authorized',
    category: 'mobiles',
    tagline: 'A17 Pro Bionic Gaming, Grade 5 Titanium Body, 48MP Pro Camera System & USB-C 3.',
    price: 119990,
    originalPrice: 134900,
    rating: 4.9,
    reviewsCount: 890,
    inStock: true,
    warrantyYears: 1,
    deliveryDays: 0,
    energyRating: '100% Battery Health Certified',
    modelNumber: 'A3102-IND',
    iconType: 'mobiles',
    imageUrl: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 4999,
    emiMonths: [3, 6, 9, 12, 18, 24],
    zeroDownPayment: true,
    exchangeBonus: 10000,
    highlights: [
      'Aerospace-grade titanium design with textured matte-glass back',
      'Customizable Action button for quick access to camera, flashlight, or shortcuts',
      'Super Retina XDR 120Hz ProMotion with Always-On display technology',
      'Same-day doorstep delivery with complimentary data transfer assistance'
    ],
    specs: {
      'Display': '6.1" Super Retina XDR OLED (2556 x 1179) 120Hz ProMotion',
      'Processor': 'A17 Pro chip with 6-core GPU and hardware ray tracing',
      'Storage': '256 GB NVMe High Speed',
      'Main Camera': '48MP Main + 12MP Ultra Wide + 12MP 3x Telephoto',
      'Battery': '3274 mAh with All-Day Battery Life',
      'Charging': 'USB-C (up to 10Gb/s) & MagSafe 15W Wireless',
      'Durability': 'Ceramic Shield front with IP68 Water Resistance'
    },
    services: [
      {
        id: 'srv-iphone-batt-swap',
        name: 'Genuine Apple Battery Replacement (30-Mins)',
        description: 'Restores 100% Maximum Capacity health without error warnings, with waterproof seal.',
        price: 3490,
        durationMinutes: 30,
        warrantyDays: 365
      }
    ]
  },
  {
    id: 'comp-macbook-air-m2',
    name: 'Apple MacBook Air M2 (13.6" Liquid Retina, 8GB RAM, 256GB SSD)',
    brand: 'Apple Authorized',
    category: 'mobiles',
    tagline: 'M2 Chip with 8-Core CPU & 8-Core GPU, 18-Hour Battery Life, MagSafe 3 & 1080p FaceTime HD Camera.',
    price: 94990,
    originalPrice: 114900,
    rating: 4.9,
    reviewsCount: 610,
    inStock: true,
    warrantyYears: 1,
    deliveryDays: 0,
    energyRating: '18h Battery Life',
    modelNumber: 'MLXW3HN/A',
    iconType: 'mobiles',
    imageUrl: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 3957,
    emiMonths: [3, 6, 9, 12, 18, 24],
    zeroDownPayment: true,
    exchangeBonus: 8000,
    highlights: [
      'Strikingly thin all-aluminum unibody design in Midnight and Space Grey',
      'Apple M2 chip with blazing CPU performance and silent fanless cooling',
      '13.6-inch Liquid Retina display with 500 nits of brightness and P3 wide color',
      'MagSafe 3 fast charging with two Thunderbolt / USB 4 ports'
    ],
    specs: {
      'Display': '13.6" Liquid Retina LED-backlit (2560 x 1664) with True Tone',
      'Processor': 'Apple M2 chip (8-core CPU, 8-core GPU, 16-core Neural Engine)',
      'Memory': '8GB unified memory',
      'Storage': '256GB SSD storage',
      'Battery': '52.6-watt-hour lithium-polymer with up to 18 hours video playback',
      'Audio': 'Four-speaker sound system with Spatial Audio support',
      'Weight': 'Ultra-portable 1.24 kg'
    },
    services: [
      {
        id: 'srv-macbook-tuneup',
        name: 'macOS Thermal Dust Clean & Diagnostic',
        description: 'Internal motherboard dust removal, trackpad calibration, and macOS reinstall.',
        price: 1490,
        durationMinutes: 45,
        warrantyDays: 90
      }
    ]
  },
  {
    id: 'audio-airpods-pro-2',
    name: 'Apple AirPods Pro (2nd Gen) with USB-C MagSafe Case',
    brand: 'Apple Authorized',
    category: 'mobiles',
    tagline: 'Up to 2x More Active Noise Cancellation, Adaptive Audio, Transparency Mode & Personalized Spatial Audio.',
    price: 22990,
    originalPrice: 24900,
    rating: 4.9,
    reviewsCount: 820,
    inStock: true,
    warrantyYears: 1,
    deliveryDays: 0,
    energyRating: '30h Total Playtime',
    modelNumber: 'MTJV3HN/A',
    iconType: 'mobiles',
    imageUrl: 'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 1915,
    emiMonths: [3, 6, 9, 12],
    zeroDownPayment: true,
    exchangeBonus: 2000,
    highlights: [
      'H2 Apple Silicon chip delivers smarter noise cancellation and immersive 3D sound',
      'Adaptive Audio dynamically blends Transparency and Active Noise Cancellation',
      'Dust, sweat, and water-resistant (IP54) earbuds and MagSafe charging case with speaker',
      'Up to 6 hours of listening time with ANC on (up to 30 hours with case)'
    ],
    specs: {
      'Audio Tech': 'Custom high-excursion Apple driver & custom high dynamic range amplifier',
      'Chip': 'Apple H2 headphone chip, Apple U1 chip in MagSafe charging case',
      'Sensors': 'Dual beamforming microphones, skin-detect sensor, motion & speech accelerometers',
      'Connectivity': 'Bluetooth 5.3 wireless technology',
      'Charging Case': 'Works with MagSafe charger, Apple Watch charger, Qi-certified chargers, or USB-C'
    },
    services: [
      {
        id: 'srv-airpods-clean',
        name: 'Acoustic Mesh Sonic Cleaning & Sanitization',
        description: 'Ultrasonic earwax removal from speaker grills and microphone ports.',
        price: 499,
        durationMinutes: 20,
        warrantyDays: 30
      }
    ]
  },
  {
    id: 'wear-galaxy-watch-6',
    name: 'Samsung Galaxy Watch 6 LTE (44mm Super AMOLED, Sapphire Crystal)',
    brand: 'Samsung India',
    category: 'mobiles',
    tagline: 'Advanced Sleep Coaching, ECG & Blood Pressure Sensor, Body Composition Analysis & 4G LTE Calling.',
    price: 26990,
    originalPrice: 33999,
    rating: 4.8,
    reviewsCount: 430,
    inStock: true,
    warrantyYears: 1,
    deliveryDays: 0,
    energyRating: 'All-Day Battery',
    modelNumber: 'SM-R945F',
    iconType: 'mobiles',
    imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 2249,
    emiMonths: [3, 6, 9, 12],
    zeroDownPayment: true,
    exchangeBonus: 3500,
    highlights: [
      '20% larger display with thinner bezel on ultra-durable Sapphire Crystal glass',
      'Personalized Heart Rate zones and continuous ECG rhythm tracking',
      'Standalone 4G LTE eSIM connectivity for calls and texts without your phone',
      'IP68 + 5ATM water resistance up to 50 meters for swimming'
    ],
    specs: {
      'Display': '1.5" (37.3mm) Super AMOLED (480 x 480) with Sapphire Crystal',
      'Processor': 'Exynos W930 Dual Core 1.4GHz',
      'Memory & Storage': '2.0GB RAM + 16GB internal storage',
      'Sensors': 'Samsung BioActive Sensor (Optical Heart Rate + Electrical Heart + BIA)',
      'Durability': '5ATM + IP68 / MIL-STD-810H military spec grade'
    },
    services: [
      {
        id: 'srv-watch-strap',
        name: 'Strap Customization & Waterproof Seal Test',
        description: 'High-pressure water chamber test and titanium pin replacement.',
        price: 399,
        durationMinutes: 15,
        warrantyDays: 60
      }
    ]
  },
  {
    id: 'mob-galaxy-s24-ultra',
    name: 'Samsung Galaxy S24 Ultra 5G (12GB RAM, 256GB)',
    brand: 'Samsung India',
    category: 'mobiles',
    tagline: 'Galaxy AI, Built-in S-Pen, 200MP Quad Camera, Snapdragon 8 Gen 3 & Titanium Armor.',
    price: 109990,
    originalPrice: 129990,
    rating: 4.9,
    reviewsCount: 740,
    inStock: true,
    warrantyYears: 1,
    deliveryDays: 0,
    energyRating: '5000 mAh Dual-Cell',
    modelNumber: 'SM-S928B',
    iconType: 'mobiles',
    imageUrl: 'https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 4582,
    emiMonths: [3, 6, 9, 12, 18, 24],
    zeroDownPayment: true,
    exchangeBonus: 9000,
    highlights: [
      'Galaxy AI Live Translate, Circle to Search with Google, and Note Assist',
      'Corning Gorilla Armor reduces glare up to 75% under bright outdoor sunlight',
      'Built-in precision S-Pen for handwriting, document signing, and air gestures',
      '7 Years of guaranteed Android OS upgrades & security updates'
    ],
    specs: {
      'Display': '6.8" Dynamic AMOLED 2X QHD+ (3120 x 1440) 120Hz 2600 nits',
      'Processor': 'Snapdragon 8 Gen 3 for Galaxy (4nm)',
      'Memory & Storage': '12GB LPDDR5X RAM | 256GB UFS 4.0',
      'Camera': '200MP Main + 50MP 5x Optical + 10MP 3x + 12MP Ultra Wide',
      'Battery': '5000 mAh with 45W Fast Charging Support',
      'Durability': 'Titanium Frame with IP68 Submersion Rating'
    },
    services: [
      {
        id: 'srv-s24-battery-swap',
        name: 'NovaPower 5000mAh Battery Swap & Glass Seal',
        description: 'New cell installation with original back glass adhesive clamp pressure.',
        price: 2490,
        durationMinutes: 35,
        warrantyDays: 365
      }
    ]
  },

  // ==================== 6. INVERTERS & SOLAR BATTERIES ====================
  {
    id: 'inv-luminous-combo-150',
    name: 'Luminous EcoVolt 1100 Pure Sinewave Inverter + 150Ah Battery',
    brand: 'Luminous Power',
    category: 'inverter',
    tagline: 'Heavy-Duty Home Power Backup Set for 3 Fans, 4 Lights, TV & Wi-Fi during Power Cuts.',
    price: 18990,
    originalPrice: 24990,
    rating: 4.9,
    reviewsCount: 950,
    inStock: true,
    warrantyYears: 3,
    deliveryDays: 1,
    energyRating: 'Pure Sinewave 900VA / 150Ah',
    modelNumber: 'EV1100-RC18000',
    iconType: 'inverter',
    imageUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 1582,
    emiMonths: [3, 6, 9, 12],
    zeroDownPayment: true,
    exchangeBonus: 3000,
    highlights: [
      'Complete home backup combo: 900VA Inverter + 150Ah Red Charge Tall Tubular Battery',
      'Pure sinewave output prevents humming noise in fans and protects sensitive TVs',
      'Adaptive Battery Charging Control (ABCC) charges fast and extends battery life',
      'Free doorstep delivery and battery trolley setup included'
    ],
    specs: {
      'Inverter Capacity': '900VA / 756W Output Pure Sinewave',
      'Battery Capacity': '150Ah Tall Tubular Lead-Acid Battery',
      'Backup Duration': '4 to 6 Hours on typical home load (Fans, TV, Router, LED bulbs)',
      'Battery Warranty': '36 Months Replacement + 24 Months Pro-Rata',
      'Display Indicators': 'Mains On, Battery Charging, Eco/UPS Mode, Overload, Low Battery',
      'Dimensions': 'Compact Tall Tubular Footprint with Acid Level Float Indicators'
    },
    services: [
      {
        id: 'srv-inverter-install',
        name: 'Heavy Duty Inverter Wiring & Changeover Switch Installation',
        description: 'Complete copper wiring, MCB changeover switch, and battery terminal greasing.',
        price: 799,
        durationMinutes: 60,
        warrantyDays: 180
      }
    ]
  },

  // ==================== 7. KITCHEN APPLIANCES ====================
  {
    id: 'kitch-panasonic-microwave-27',
    name: 'Panasonic 27L Convection Microwave Oven',
    brand: 'Panasonic Japan',
    category: 'kitchen',
    tagline: '360° Heat Wrap with 101 Auto Cook Menus, Zero Oil Cooking & Stainless Steel Cavity.',
    price: 13990,
    originalPrice: 18990,
    rating: 4.8,
    reviewsCount: 340,
    inStock: true,
    warrantyYears: 3,
    deliveryDays: 1,
    energyRating: 'Energy Efficient Convection',
    modelNumber: 'NN-CT645B',
    iconType: 'kitchen',
    imageUrl: 'https://images.unsplash.com/photo-1574269909862-7e1d70bb8078?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 1165,
    emiMonths: [3, 6, 9, 12],
    zeroDownPayment: true,
    exchangeBonus: 1500,
    highlights: [
      '27 Litres capacity suitable for baking cakes, grilling tandoori, and reheating curries',
      '101 Auto-Cook menus pre-programmed for authentic Indian recipes',
      'Stainless steel rust-free cavity reflects heat evenly for crisp baking',
      'Child safety lock and deodorizer cycle included'
    ],
    specs: {
      'Capacity': '27 Litres',
      'Operation Type': 'Convection (Microwave + Grill + Baking)',
      'Power Levels': '5 Variable Microwave Power Levels (up to 900W)',
      'Cavity Material': 'Stainless Steel Anti-Bacterial Interior',
      'Turntable Size': '305 mm Heavy Tempered Glass Turntable'
    },
    services: [
      {
        id: 'srv-microwave-magnetron',
        name: 'Magnetron & High Voltage Diode Replacement',
        description: 'Diagnoses and fixes microwaves that run but fail to heat food.',
        price: 1450,
        durationMinutes: 45,
        warrantyDays: 180
      }
    ]
  },
  {
    id: 'gaming-ps5-slim',
    name: 'Sony PlayStation 5 Slim Console (1TB SSD, DualSense)',
    brand: 'Sony Interactive',
    category: 'tv',
    tagline: 'Ultra-High Speed 1TB SSD, Ray Tracing, 4K-TV Gaming, HDR Technology & Tempest 3D AudioTech.',
    price: 44990,
    originalPrice: 54990,
    rating: 4.9,
    reviewsCount: 710,
    inStock: true,
    warrantyYears: 1,
    deliveryDays: 0,
    energyRating: '1TB Ultra High-Speed SSD',
    modelNumber: 'CFI-2000',
    iconType: 'tv',
    imageUrl: 'https://images.unsplash.com/photo-1606813907291-d86efa9b94db?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 3749,
    emiMonths: [3, 6, 9, 12],
    zeroDownPayment: true,
    exchangeBonus: 5000,
    highlights: [
      'Slim design with 1TB high-speed NVMe internal storage',
      'Haptic feedback and adaptive triggers on DualSense wireless controller',
      'Supports smooth high frame rate gameplay at up to 120fps for compatible games',
      'Tempest 3D AudioTech immerses you in soundscapes where sound comes from every direction'
    ],
    specs: {
      'Storage': '1TB Custom NVMe SSD (5.5GB/s Read Bandwidth)',
      'Video Output': 'Supports 4K 120Hz TVs, 8K TVs, VRR (specified by HDMI ver.2.1)',
      'Audio': 'Tempest 3D AudioTech',
      'Processor': 'x86-64-AMD Ryzen Zen 2 (8 Cores / 16 Threads) up to 3.5 GHz',
      'Graphics': 'AMD Radeon RDNA 2-based graphics engine with Ray Tracing Acceleration'
    },
    services: [
      {
        id: 'srv-ps5-clean',
        name: 'Liquid Metal Thermal Service & Fan De-Dusting',
        description: 'Full heat sink sonic cleaning and liquid metal thermal paste re-application.',
        price: 1490,
        durationMinutes: 45,
        warrantyDays: 90
      }
    ]
  },
  {
    id: 'tab-ipad-air-m2',
    name: 'Apple iPad Air 11" M2 Chip (Liquid Retina, 128GB)',
    brand: 'Apple Authorized',
    category: 'mobiles',
    tagline: 'Apple M2 Chip, 11-inch Liquid Retina Display with P3 Wide Color, 12MP Landscape Front Camera.',
    price: 59900,
    originalPrice: 69900,
    rating: 4.9,
    reviewsCount: 460,
    inStock: true,
    warrantyYears: 1,
    deliveryDays: 0,
    energyRating: 'All-Day Battery M2',
    modelNumber: 'MUWC3HN/A',
    iconType: 'mobiles',
    imageUrl: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 4991,
    emiMonths: [3, 6, 9, 12],
    zeroDownPayment: true,
    exchangeBonus: 6000,
    highlights: [
      'Powerful Apple M2 processor with 8-core CPU and 10-core GPU',
      '11-inch Liquid Retina display with True Tone, P3 wide color, and ultra-low reflectivity',
      'Supports Apple Pencil Pro and Magic Keyboard for professional digital sketching',
      'Landscape 12MP Ultra Wide front camera with Center Stage'
    ],
    specs: {
      'Display': '11-inch LED Liquid Retina (2360 x 1640) at 264 ppi, 500 nits',
      'Processor': 'Apple M2 chip with 16-core Neural Engine',
      'Storage': '128GB High-Speed Flash',
      'Connectivity': 'Wi-Fi 6E, Bluetooth 5.3, USB-C (up to 10Gb/s)',
      'Weight': 'Lightweight 462 grams'
    },
    services: [
      {
        id: 'srv-ipad-tempered',
        name: 'Precision 9H Oleophobic Glass Shield Application',
        description: 'Zero-dust vacuum box installation with 9H tempered scratch armor.',
        price: 499,
        durationMinutes: 15,
        warrantyDays: 180
      }
    ]
  },
  {
    id: 'audio-sony-wh1000xm5',
    name: 'Sony WH-1000XM5 Wireless Noise-Cancelling Headphones',
    brand: 'Sony India',
    category: 'mobiles',
    tagline: 'Auto NC Optimizer, 8 Microphones, Integrated Processor V1 + QN1, 30-Hour Battery & Quick Charge.',
    price: 29990,
    originalPrice: 34990,
    rating: 4.9,
    reviewsCount: 880,
    inStock: true,
    warrantyYears: 1,
    deliveryDays: 0,
    energyRating: '30-Hour ANC Battery',
    modelNumber: 'WH1000XM5/B',
    iconType: 'mobiles',
    imageUrl: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 2499,
    emiMonths: [3, 6, 9, 12],
    zeroDownPayment: true,
    exchangeBonus: 3000,
    highlights: [
      'Industry-leading active noise canceling with two processors and 8 microphones',
      'Magnificent sound quality engineered with a lightweight 30mm carbon fiber driver',
      'Ultra-clear hands-free calling with 4 beamforming microphones and AI noise reduction',
      'Up to 30 hours of continuous battery life (3 minutes charge gives 3 hours playback)'
    ],
    specs: {
      'Headphone Type': 'Closed, dynamic over-ear headphones',
      'Driver Unit': '30mm Carbon Fiber composite dome',
      'Frequency Response': '4 Hz - 40,000 Hz (Hi-Res Audio Wireless with LDAC)',
      'Battery Life': 'Max 30 hours (NC ON), Max 40 hours (NC OFF)',
      'Weight': 'Lightweight 250 grams with Soft Fit Leather'
    },
    services: [
      {
        id: 'srv-headphone-earpad',
        name: 'Memory Foam Leatherette Ear Cushion Replacement',
        description: 'Original factory replacement earcups for comfort and acoustic seal.',
        price: 999,
        durationMinutes: 20,
        warrantyDays: 180
      }
    ]
  },
  {
    id: 'batt-iphone-oem-swap',
    name: 'Apple Certified OEM iPhone Replacement Battery Cell (30-Mins)',
    brand: 'Apple Authorized',
    category: 'mobiles',
    tagline: '100% Health Guaranteed, Zero Cycles, Factory BMS Microcontroller with Laser-Cut IP68 Seal.',
    price: 3490,
    originalPrice: 4990,
    rating: 5.0,
    reviewsCount: 1250,
    inStock: true,
    warrantyYears: 1,
    deliveryDays: 0,
    energyRating: '100% Health 0-Cycles',
    modelNumber: 'OEM-COBALT-PRO',
    iconType: 'battery',
    imageUrl: 'https://images.unsplash.com/photo-1588508065123-287b28e013da?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 872,
    emiMonths: [3, 6],
    zeroDownPayment: true,
    exchangeBonus: 1000,
    highlights: [
      '100% Brand-new pure cobalt battery cell with zero prior charge cycles',
      'Transfers original Apple BMS serial chip to prevent "Unknown Part" popups',
      'Restores factory 100% Maximum Capacity in iOS Battery Settings',
      'Includes laser-cut fresh IP68 water & dust resistance gasket adhesive'
    ],
    specs: {
      'Cell Chemistry': 'High-Density Lithium Cobalt Oxide (LiCoO2)',
      'Cycle Count': '0-Cycle Brand New Tested Cell',
      'Cycle Life': '800+ Full Cycles before dropping below 80% health',
      'Safety Standard': 'BIS Approved / CE Certified / Overcharge Protection IC',
      'Swap Duration': '30 Minutes On-Spot Doorstep or In-Store Service'
    },
    services: [
      {
        id: 'srv-batt-check',
        name: 'Free 24-Point Comprehensive Motherboard & Power Audit',
        description: 'Diagnostic current draw testing, charging port inspection, and firmware check.',
        price: 0,
        durationMinutes: 15,
        warrantyDays: 365
      }
    ]
  },
  {
    id: 'kitch-philips-airfryer-xl',
    name: 'Philips Digital Connected XXL Airfryer (7.2 Litres, 2000W)',
    brand: 'Philips Home',
    category: 'kitchen',
    tagline: 'Rapid Air Technology with 90% Less Fat, NutriU App Connectivity & 16-in-1 Cooking Presets.',
    price: 12990,
    originalPrice: 16995,
    rating: 4.8,
    reviewsCount: 390,
    inStock: true,
    warrantyYears: 2,
    deliveryDays: 1,
    energyRating: '2000W Rapid Air',
    modelNumber: 'HD9285/90',
    iconType: 'kitchen',
    imageUrl: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1200&q=80',
    emiPerMonth: 1082,
    emiMonths: [3, 6, 9, 12],
    zeroDownPayment: true,
    exchangeBonus: 1500,
    highlights: [
      '7.2 Litre basket capacity cooks up to 6 portions of food in a single batch',
      'Rapid Air technology creates delicious crispy food with up to 90% less oil',
      'Connects with NutriU app for hundreds of curated healthy Indian & international recipes',
      'QuickClean basket with non-stick coating for effortless cleaning'
    ],
    specs: {
      'Capacity': '7.2 Litres (1.4 kg capacity)',
      'Power': '2000 Watts High Efficiency Heating Coil',
      'Presets': '16-in-1 Functions: Fry, Bake, Grill, Roast, Dehydrate, Reheat',
      'Control': 'Digital Touch Screen with Temperature Dial (40°C - 200°C)',
      'Dishwasher Safe': 'All removable parts are fully dishwasher safe'
    },
    services: [
      {
        id: 'srv-airfryer-element',
        name: 'Heating Element & Thermostat Precision Calibration',
        description: 'Complete inspection and thermal coil cleaning service.',
        price: 899,
        durationMinutes: 40,
        warrantyDays: 180
      }
    ]
  }
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 't-1',
    name: 'Rameshwar Prasad Sharma',
    location: 'Civil Lines Showroom Customer',
    deviceWorkedOn: 'Sony Bravia 65" 4K TV via Bajaj Finserv EMI',
    type: 'Appliance Purchase with EMI',
    rating: 5,
    verified: true,
    comment: 'Purchased a 65-inch Sony Bravia TV on 0% No-Cost EMI via Bajaj Finserv from Maa Gayatri Electronics. Paid zero down payment upfront, and their certified team mounted it flush on my wall the very same evening. We have trusted this showroom for over a decade!',
    date: '3 days ago',
    savingsOrOutcome: '0% Interest EMI · Zero Down Payment'
  },
  {
    id: 't-2',
    name: 'Sunita Verma',
    location: 'Gandhi Nagar Resident',
    deviceWorkedOn: 'Samsung 580L Bespoke Fridge (Old Fridge Traded In)',
    type: 'Exchange Deal',
    rating: 5,
    verified: true,
    comment: 'Traded in our 12-year-old single-door refrigerator. The Maa Gayatri valuation team immediately deducted ₹6,000 off our order total and delivered the new Bespoke French-Door refrigerator that afternoon with full demo and warranty registration.',
    date: '1 week ago',
    savingsOrOutcome: 'Instant ₹6,000 Trade-In Discount'
  },
  {
    id: 't-3',
    name: 'Mohit Agrawal',
    location: 'Station Road Resident',
    deviceWorkedOn: 'Daikin 1.5 Ton 5-Star Inverter AC',
    type: 'Appliance Purchase with EMI',
    rating: 5,
    verified: true,
    comment: 'Installed a Daikin 5-star inverter AC for the summer. Secured a 6-month No-Cost EMI on my HDFC card with zero extra interest charges. Copper piping and outdoor stands were provided at direct dealer rates.',
    date: '2 weeks ago',
    savingsOrOutcome: 'Saved ₹15,000 vs MRP + Free Installation'
  },
  {
    id: 't-4',
    name: 'Deepak Kumar Soni',
    location: 'Rajendra Nagar Resident',
    deviceWorkedOn: 'Luminous Inverter & 150Ah Tubular Battery Set',
    type: 'Appliance Purchase with EMI',
    rating: 5,
    verified: true,
    comment: 'Frequent power cuts were disrupting our work. Bought the Luminous pure sinewave inverter and 150Ah battery system from Maa Gayatri Electronics on an easy ₹1,582/month installment plan. Runs our fans and TV flawlessly.',
    date: 'Yesterday',
    savingsOrOutcome: 'Easy ₹1,582/mo Power Backup System'
  }
];

export const TRUST_METRICS = [
  { label: 'Families Served', value: '35,000+', sub: '15+ Years trusted local showroom legacy' },
  { label: '0% No-Cost EMI', value: 'Zero Down', sub: 'Instant approval in under 60 seconds' },
  { label: 'Authorized Brand Dealer', value: '100% Genuine', sub: 'Daikin, LG, Samsung, Sony, Apple' },
  { label: 'Trade-In Valuation', value: 'Up to ₹10,000', sub: 'Instant deduction on old appliances' }
];

export const DIAGNOSTIC_CATEGORIES = [
  {
    id: 'ac',
    label: 'Air Conditioner',
    models: ['Split Inverter AC (1–2 Ton)', 'Window AC', 'Commercial AC'],
    issues: [
      { name: 'Not Cooling / Warm Air Flow', estimate: '₹999 – ₹2,450', time: '45 mins', likelyFix: 'Gas Top-up or Jet Coil Cleaning' },
      { name: 'Water Dripping from Indoor Unit', estimate: '₹599 – ₹850', time: '30 mins', likelyFix: 'Drain Pipe De-clogging & Pan Alignment' },
      { name: 'Strange Noise / Compressor Not Starting', estimate: '₹850 – ₹1,800', time: '50 mins', likelyFix: 'Capacitor or Blower Motor Repair' }
    ]
  },
  {
    id: 'tv',
    label: 'Smart TV (4K / OLED / LED)',
    models: ['Sony / Samsung 4K TV (43"-65")', 'OLED Cinema TV', 'Smart LED TV'],
    issues: [
      { name: 'Sound is Working but Screen is Blank', estimate: '₹1,800 – ₹2,800', time: '60 mins', likelyFix: 'LED Backlight Strip Replacement' },
      { name: 'Horizontal or Vertical Lines on Display', estimate: '₹2,200 – ₹3,800', time: '75 mins', likelyFix: 'T-Con Board / Display Panel Diagnostic' },
      { name: 'Red Standby Light Blinking / No Power', estimate: '₹1,200 – ₹2,400', time: '45 mins', likelyFix: 'Power Supply Board Rebuild' }
    ]
  },
  {
    id: 'fridge',
    label: 'Refrigerator',
    models: ['French Door Multi-Door Fridge', 'Double Door Frost-Free', 'Single Door Direct Cool'],
    issues: [
      { name: 'Freezer Working but Bottom Fridge Warm', estimate: '₹1,200 – ₹1,850', time: '50 mins', likelyFix: 'Defrost Sensor / Evaporator Fan Swap' },
      { name: 'Compressor Humming and Clicking Off', estimate: '₹1,800 – ₹4,500', time: '90 mins', likelyFix: 'Inverter Relay or Compressor Fix' },
      { name: 'Water Leakage Under Vegetable Tray', estimate: '₹650 – ₹950', time: '35 mins', likelyFix: 'Drain Defrost Hole Cleaning' }
    ]
  },
  {
    id: 'washing',
    label: 'Washing Machine',
    models: ['Front Load Inverter Machine', 'Top Load Fully Automatic', 'Semi-Automatic'],
    issues: [
      { name: 'Machine Not Spinning or Making Loud Noise', estimate: '₹850 – ₹1,800', time: '45 mins', likelyFix: 'Drum Bearings or Drive Belt Fix' },
      { name: 'Water Not Draining / Error Code on Screen', estimate: '₹650 – ₹1,100', time: '35 mins', likelyFix: 'Drain Pump Filter Cleaning' }
    ]
  },
  {
    id: 'mobiles',
    label: 'Smartphone & Battery',
    models: ['Apple iPhone (11 through 15 Pro Max)', 'Samsung Galaxy S/A Series', 'OnePlus & Pixel Flagships'],
    issues: [
      { name: 'Battery Health <80% or Draining Rapidly', estimate: '₹1,890 – ₹3,490', time: '30 mins', likelyFix: 'Direct OEM High-Capacity Battery Swap' },
      { name: 'Phone Shuts Down Abruptly at 20%', estimate: '₹1,890 – ₹2,490', time: '30 mins', likelyFix: 'Cell Calibration & 100% Health Swap' }
    ]
  }
];
