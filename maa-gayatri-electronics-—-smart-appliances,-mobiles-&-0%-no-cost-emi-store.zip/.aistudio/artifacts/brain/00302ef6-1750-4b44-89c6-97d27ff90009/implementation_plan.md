# VoltaTech — Modern Smart Tech & Appliance Hub

An Apple-style minimalist, high-conversion tech platform delivering premium sales, certified repairs, and express battery replacements for smart appliances (ACs, 4K/OLED TVs, Smart Refrigerators) and mobile phone batteries.

### User Review & Critical Decisions

> [!IMPORTANT]
> Based on your confirmed choices, the website will embody a **Clean Apple-Style Minimalist** aesthetic (crisp white canvas, high-contrast typography, generous spatial padding, zero visual clutter) and unify **Sales, Certified Repairs, and Express Battery Replacements** under one brand with a **Live Tech Specs & Service Comparison Engine** as the primary conversion anchor.

- **Confirmed Aesthetic**: Clean Apple-Style Minimal (Pure whites `#FFFFFF`, soft slate/zinc accents `#F4F4F5`, deep obsidian text `#09090B`, subtle graphite border lines `#E4E4E7`).
- **Confirmed Business Scope**: All-in-one Tech Hub for consumer electronics (ACs, Smart TVs, Refrigerators, and Phone Batteries).
- **Confirmed Conversion Anchor**: Live side-by-side Specs & Service Matrix Comparator with instant quote and booking actions.
- **Customer Conversion Focus**: Trust badges (1-Year OEM Warranty, 45-Min Express Doorstep, 100% Genuine Parts, Zero Hidden Diagnostic Fees), social proof with verified customer case studies, and transparent cost breakdown.

---

### 1. Overview & Core Concept

- **What It Does**: VoltaTech allows customers to explore premium tech appliances, compare hardware specifications & repair warranties in real time, calculate instant service/battery swap costs, and complete purchases or doorstep booking with total transparency.
- **Target Audience / Persona**: Tech-savvy homeowners and professionals seeking trustworthy, fast appliance purchases and authentic repair/battery services without haggling or counterfeit parts.
- **Key Value Proposition**: Transparent pricing, 365-day warranty on all services and parts, 45-minute express doorstep technicians, and a clean, clutter-free Apple-grade customer experience designed to eliminate buyer hesitation.

---

### 2. User Experience & Visual Design

#### Key User Flows
1. **Hero & Category Navigation**: Customer lands on a pristine minimalist hero with dynamic feature callouts (AC cooling performance, OLED display clarity, inverter compressor efficiency, and 100% health phone batteries), followed by smooth category filtering.
2. **Interactive Live Comparison Bar & Modal**: Customer selects 2–3 products or repair services across categories and opens the full-screen side-by-side comparison modal with spec matrices, energy efficiency ratings, warranty tiers, and instant purchase/booking buttons.
3. **Instant Repair & Battery Diagnostic Estimator**: A 3-step interactive widget where the customer selects their appliance/device (e.g., iPhone 15 battery or LG Split AC), selects the symptom (e.g., rapid battery drain, cooling loss, or screen flicker), and receives an instant OEM price quote with scheduling.
4. **Product & Service Showcase with Detail Drawer**: Interactive product cards with high-fidelity imagery, key technical highlights (BTU/Tonnage, 120Hz Refresh, Dual Inverter, Battery Cycle Count), and a slide-out purchase/appointment drawer.
5. **Trust & Conversion Section**: Transparent pricing promise, customer ratings (4.9/5 from 12,400+ jobs), certified technician credentials, and money-back guarantee badges.

#### Visual Identity & Theme
- **Aesthetic Direction**: Apple-inspired clean luxury minimalism. High clarity, deliberate whitespace, subtle micro-borders, and tactile interaction states.
- **Color Palette**:
  - Background Canvas: `#FFFFFF` (Pure white) with `#FAFAFA` and `#F4F4F5` surface tints.
  - Text & Accents: Obsidian `#09090B` for high-impact display typography, `#71717A` for metadata and technical descriptions.
  - Active Accents: Apple Blue `#0071E3` for focused primary actions and emerald `#10B981` for genuine OEM certification badges.
- **Typography & Scale**:
  - Display Font: Inter / Plus Jakarta Sans style geometric sans-serif with `tracking-tight` and balanced line wrapping.
  - Numbers & Metrics: Tabular monospace figures (`font-mono tabular-nums`) for prices, kilowatt hours, battery mAh, and turnaround times.
- **Component Styling & Anti-Slop Rules**:
  - Strictly zero-pill metadata (plain text tags separated by subtle middots `·`).
  - Strict Top Bar Contract: 1-line brand title, 4 clean nav links, 1 primary action button.
  - Single-elevation cards with hairline borders (`border border-zinc-200/80`) and no multi-colored neon gradients.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Unified All-in-One Architecture (Buy + Repair + Battery)**
  - *Chosen Approach*: Group products into clear multi-faceted cards featuring both "Buy New / Certified Refurbished" and "Book Repair / Battery Swap" tabs.
  - *Why*: Directly addresses customer hesitation — if an appliance is broken, they can either get it fixed affordably today or upgrade to a new model with exchange value.
  - *Alternatives Considered*: Separate split sites for sales and repairs (rejected to maintain strong brand unity and cross-sell).

- **Decision 2: Live Comparison Drawer with Persistent Dock**
  - *Chosen Approach*: A bottom docked comparison trigger that activates when products are flagged for comparison, expanding into a clean modal matrix.
  - *Why*: Allows frictionless exploration without navigating away from the catalog.

- **Decision 3: Zero-Friction Booking & Cart Drawer**
  - *Chosen Approach*: Slide-over checkout and service scheduling drawer with immediate order confirmation modal and printable summary.
  - *Why*: High conversion with zero login hurdles or complex redirects.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────────┐
│                           VoltaTech                             │
│                  (Vite + React 19 + Tailwind CSS)               │
└─────────────────────────────────────────────────────────────────┘
                               │
       ┌───────────────────────┼───────────────────────┐
       ▼                       ▼                       ▼
┌──────────────┐       ┌──────────────┐        ┌──────────────┐
│  Top Bar     │       │ Catalog &    │        │ Comparison   │
│  Navigation  │       │ Showcase     │        │ Engine       │
│  (3-Zone)    │       │ (AC, TV, Re- │        │ (Side-by-    │
│              │       │ frigerator,  │        │ Side Matrix) │
│              │       │ Phone Bat.)  │        │              │
└──────────────┘       └──────────────┘        └──────────────┘
       │                       │                       │
       ▼                       ▼                       ▼
┌──────────────┐       ┌──────────────┐        ┌──────────────┐
│ Instant      │       │ Trust &      │        │ Booking &    │
│ Diagnostic   │       │ Customer     │        │ Cart Drawer  │
│ Estimator    │       │ Proof        │        │ (Checkout &  │
│ (3-Step)     │       │ Section      │        │ Schedule)    │
└──────────────┘       └──────────────┘        └──────────────┘
```

#### Core Data Entities
- **DeviceCategory**: `ac` | `tv` | `fridge` | `battery`
- **ProductItem**: `id`, `name`, `category`, `price`, `originalPrice`, `rating`, `reviewsCount`, `specs` (key-value technical matrix), `serviceOptions` (repair cost, battery health test, gas refill), `warrantyMonths`, `deliveryDays`, `image`.
- **ComparisonState**: Array of selected `ProductItem` IDs (up to 3 items) compared across dimensions (energy rating, resolution/capacity, OEM warranty, repair feasibility, cost).
- **Cart & BookingState**: Array of items with selected service type (Purchase vs Doorstep Repair Booking), customer details, slot selection, and total pricing.

---

### 5. Implementation Roadmap
1. **Asset Generation**: Generate high-definition studio product imagery for AC, 4K OLED TV, Smart French-Door Refrigerator, and High-Performance Phone Battery using the `generate_image` tool.
2. **State Management & Data Store**: Establish mockable, realistic catalog with real specifications (LG Dual Inverter AC, Sony Bravia XR OLED, Samsung Bespoke Smart Fridge, Apple iPhone / Samsung Galaxy OEM Battery swap packages).
3. **Core Interactive Components**:
   - Navigation Bar following Top Bar Contract.
   - Hero Showcase with category switcher and value propositions.
   - Live Product Specs Comparison modal with side-by-side highlight diffing.
   - Interactive Diagnostic & Repair Cost Estimator with instant quote generator.
   - Product Grid with quick-compare toggles, specifications preview, and add-to-cart/book-repair actions.
   - Customer Trust & Testimonial section with verified repair case studies.
   - Slide-over Booking & Checkout Drawer with order confirmation view.
4. **Verification & Polish**: Run `compile_applet` and verify responsive layouts, WCAG contrast, and interactive feedback.
